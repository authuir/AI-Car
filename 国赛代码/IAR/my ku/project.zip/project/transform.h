#ifndef __TRANSFORM_H__
#define __TRANSFORM_H__

#include "all.h"

#define BmpWidthX 180
#define BmpHeightX 120
#define OutWidthX 223
#define OutHeightX 300

void Send_Transformed(void);
uint8 Get_Transform_Value(uint16 i,uint16 j);

#endif