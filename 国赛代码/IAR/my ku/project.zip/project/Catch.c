#include "all.h"
#include "Catch.h"
#include "math.h"
//#define Th_Open1  //�Զ���ֵ��1  �����С
uint8 error_flag=0;uint16 error_value=0,error_valuexx=0;
#define Th_Open2   //�Զ���ֵ��2    ƽ��
#define ERROR  255
#define Th_change_time   1
#define slope_min 17000   //�����µ�����
const uint16 RST0[X_MAX*Y_MAX] = {0};
const uint16 RST1[X_MAX*Y_MAX] ={0};
uint8   date[X_MAX][Y_MAX + 15];//�ɼ�����ͼ��
uint16  center_dot = 0,center_change=0,ave_line[60][2],ave_dot;//���ߵ�����͵���
int16 center[300][2];
uint16 left_line[500][2], right_line[500][2], left_dot = 0, right_dot = 0;//�����ߵ�����͵���
uint16 left_last = 0, right_last = Y_MAX;  //ͼ���������������߽�
uint16 start_single = 0;//�������ڵ�ͼ���ǵ���ģʽ��������ģʽ
uint16 threshold = 110, threshold_left = 110, threshold_right = 110, threshold_max=130, threshold_min=0,threshold_left_next=110,threshold_right_next=110;//?D?��
uint16 auto_threshold_left[500],auto_threshold_right[500],auto_left_times=0,auto_right_times=0;
uint16 type = 0;//������������
uint8 left_lose = 0, right_lose = 0;   //���߲�����ĳһ���Ѳ�����1
uint8 scan_mode = 0;//0��ʾ��ɨ�裬1��ʾ��ɨ��
uint16 change_left_dot, change_right_dot;
uint8 change_times = 0;
float an;
uint8 add_line=1;//����ʮ���Ƿ�
#define R_large 31
uint16  R_main = R_large;//�����Բ�뾶
uint16 single_get_hang,single_start=0,single_in=0,single_left=3,single_right=Y_MAX-3,start_with_single=0;
uint32 image_times=0,dark_image=0,no_dark_image=0,dark_flag=0,dark_times=0,angle_then=0;
float CircleR;
Line CircleDot;
Line center_2;
uint16 forward_see=X_MAX_OUT;
void CAM_get()
 {
     uint32 sum_area=0;
     uint16 i=0;single_in=2;
          center_dot = 0;
     k_ptemp=k_p;center_dot=0;
     image_times++;auto_left_times=0,auto_right_times=0;
     left_dot = 0; right_dot = 0; left_lose = 0; right_lose = 0;
     scan_mode = 0; change_times = 0;change_left_dot=0;change_right_dot=0;
     if(threshold_left_next<255)
      {
          threshold_left=threshold_left_next;threshold_right=threshold_right_next;
      }
#if  0
     if (start_single)//����ǵ���ģʽ���һ�׼��
      {
          single_mode();
      }
     if (!start_single) 		//�ǵ���ģʽ���һ�׼��
      {
          two_wile_mode();//ֻҪ�ѵ�һ���ߣ��ͼ�����ɨ�裬���򲻽�����ɨ��
      }
#endif
     if( single_mode()) scan_mode=1;
     else scan_mode=0;
     if (scan_mode == 0)   //�ѵ�����һ���ߣ����ѵ��ı���ɨ��ֱ��ת�����ߵ���߽�
      {
          two_wile_mode();
          add_line=1;
          auto_left_times=auto_right_times=0;
          hang_scan();//����ֱ��������߽���߶��Ѳ���Ϊֹ
          //ת�۵�
          change_left_dot=change_get(left_line,left_dot);
          change_right_dot=change_get(right_line,right_dot);
          left_dot=change_left_dot;
          right_dot=change_right_dot;
          auto_left_times=left_dot;
          auto_right_times=right_dot;
#ifdef Th_Open2
             uint32 sum_auto=0;
          if((auto_left_times>=50)||(auto_right_times>=50))
           {
               if(auto_left_times>auto_right_times)
                {
                    for(i=50/3;i<50*2/3;i++)
                        sum_auto+=auto_threshold_left[i];
                }
               else 
                {
                    for(i=50/3;i<50*2/3;i++)
                        sum_auto+=auto_threshold_right[i];
                }
               threshold_left_next=sum_auto/(50*2/3-50/3+1);
                threshold_right_next=threshold_left_next;
           }
          auto_left_times=0;auto_right_times=0;
#endif
         type_get();
         if(type==5)
          {
              if(left_dot>right_dot) 
               {get_roll_left(R_main,X_MAX_OUT);single_in=left_dot;}
              else {single_in=right_dot;get_roll_right(R_main,X_MAX_OUT);}
              single_left=left_line[left_dot-2][1];single_right=right_line[right_dot-2][1];
          }
         if(type==6) type6_line();
         if(type==7) 
          {
              type=0;
              /*sum_area=area_sum();
              if(sum_area>slope_min)
                  type==7;
              else type=0;*/
          }
          // UART_SS(UART0,"TPYE_GET");
      }
     else
      {
          hang_scan();
          change_left_dot=change_get(left_line,left_dot);
          change_right_dot=change_get(right_line,right_dot);
          left_dot=change_left_dot;
          right_dot=change_right_dot;
#ifdef Th_Open2
              uint32 sum_auto=0;
          if((auto_left_times>=50)||(auto_right_times>=50))
           {
               if(auto_left_times>auto_right_times)
                {
                    for(i=50/3;i<50*2/3;i++)
                        sum_auto+=auto_threshold_left[i];
                }
               else 
                {
                    for(i=50/3;i<50*2/3;i++)
                        sum_auto+=auto_threshold_right[i];
                }
               threshold_left_next=sum_auto/(50*2/3-50/3+1);
               threshold_right_next=threshold_left_next;
           }
          auto_left_times=0;auto_right_times=0;
#endif
          add_line=0;
          //type_get();
      }
     switch (type)
      {
      case 0:
          change_left_dot=left_dot-1;change_right_dot=right_dot-1;forward_see=X_MAX_OUT;
          //  UART_SS(UART0,"TYPE0_end");
          break;
      case 1:
          //  UART_SS(UART0,"TYPE1_start");
          change_left_dot=left_dot-1;change_right_dot=right_dot-1;type1_line();forward_see=X_MAX_OUT;R_main=R_large;
          // UART_SS(UART0,"TYPE1_end");
          break;
      case 2:
          //  UART_SS(UART0,"TYPE2_start");
          change_left_dot=left_dot-1;change_right_dot=right_dot-1;type2_line(); forward_see=X_MAX_OUT;R_main=R_large;
          //  UART_SS(UART0,"TYPE2_end");
          break;
      case 3:
          //   UART_SS(UART0,"TYPE3_start");
          type3_line(); change_left_dot=left_dot-1;change_right_dot=right_dot-1;forward_see=X_MAX_OUT;R_main=R_large;
          //     UART_SS(UART0,"TYPE0_end");
          break;
      case 4:
          //   UART_SS(UART0,"TYPE4_start");
	  if(type4_line())  {error_flag=7 ;hang_scan();  error_flag=8 ;} change_left_dot=left_dot-1;change_right_dot=right_dot-1;forward_see=X_MAX_OUT;R_main=R_large;
          //  UART_SS(UART0,"TYPE4_end");
	  
          break;
      case 5:
          //  UART_SS(UART0,"TYPE5_start");
          hang_scan();
          type_get();
          type=5;change_left_dot=left_dot-1;change_right_dot=right_dot-1; 
          //  UART_SS(UART0,"TYPE5_end");
          break;
       case 6:change_left_dot=left_dot-1;change_right_dot=right_dot-1;forward_see=X_MAX_OUT;break;
      case 7: change_left_dot=left_dot-1;change_right_dot=right_dot-1;break;
      }
     error_flag=0 ;
#if  0//�ֶθ��ٵ㣬б�ʿ���  K_B���Ʒ�
     if((type==0)||(type==6))
      {
          if(left_dot>right_dot) get_roll_left(R_main,forward_see);
          else get_roll_right(R_main,forward_see);
          k_output=solv_line_k(center,0,center_dot,0,&b,1,0);
      }
     else if((type==1)||(type==2))
      {
          uint16 change_angle=0;
          if(left_dot>right_dot) get_roll_left(R_main,forward_see);
          else get_roll_right(R_main,forward_see);
          if(change_angle=change_get2(center,center_dot))
            center_2=Delete_In_Corner(center,center_dot,change_angle);
          else angle_type=0;
         // k_output=solv_line_k(center_2.dot,0,center_2.num*2/3,0,&b,1,0);
          k_output=solv_line_k(center,0,center_dot,0,&b,1,0);
          if((angle_type==1)||(angle_type==2))
           {
             k_output=2*solv_line_k(center_2.dot,0,center_2.num,0,&b,1,0);
           }
          if((angle_type==1)&&(k_output<0))  k_output/=-1;
          if((angle_type==2)&&(k_output>0))  k_output/=-1;
      }
     else if((type==3)||(type==4))
      {
	            error_flag=9 ;
          if(left_dot>right_dot) get_roll_left(R_main,forward_see);
          else get_roll_right(R_main,forward_see);
          k_output=solv_line_k(center,0,center_dot,0,&b,1,0);
      }
     else if(type==5)
      {
          if(left_dot>right_dot)
           {
               for(i=single_in;i<left_dot;i+=2)
                {
                    center[center_dot][0]=RST0[left_line[i][0] * Y_MAX + left_line[i][1]];
                    center[center_dot++][1]=RST1[left_line[i][0] * Y_MAX + left_line[i][1]];
                }
           }
          else
           {
               for(i=single_in;i<right_dot;i+=2)
                {
                    center[center_dot][0]=RST0[right_line[i][0] * Y_MAX + right_line[i][1]];
                    center[center_dot++][1]=RST1[right_line[i][0] * Y_MAX + right_line[i][1]];
                }
           }
           k_output=1.1*solv_line_k(center,0,center_dot,0,&b,1,0);
      }
          error_flag=10 ;
    // send_line_other(UART0,2,(float)(type));
#endif
     
     
#if  0//�ֶθ��ٵ㣬б�ʼ���ֻ�õ����ŵĵ�
     if(type==0)
      {
          if(left_dot>right_dot) get_roll_left(R_main,forward_see);
          else get_roll_right(R_main,forward_see);
          k_output=solv_line_k(center,0,center_change,0,&b,1,0);
      }
     else if((type==1)||(type==2))
      {
          uint16 change_angle=0;float k_output_test=0;
          if(left_dot>right_dot) get_roll_left(R_main,forward_see);
          else get_roll_right(R_main,forward_see);
          if(change_angle=change_get2(center,center_dot))
              center_2=Delete_In_Corner(center,center_dot,change_angle);
          else angle_type=0;
          // k_output=solv_line_k(center_2.dot,0,center_2.num*2/3,0,&b,1,0);
          k_output_test=solv_line_k(center,0,center_change,0,&b,1,0);
          if((angle_type==1)||(angle_type==2))
           {
               k_output_test=2*solv_line_k(center_2.dot,0,center_2.num,0,&b,1,0);
           }
          if((angle_type==1)&&(k_output<0))  k_output_test/=-1;
          if((angle_type==2)&&(k_output>0))  k_output_test/=-1;
	  k_output=k_output_test;
      }
     else if((type==3)||(type==4))
      {
          if(left_dot>right_dot) get_roll_left(R_main,forward_see);
          else get_roll_right(R_main,forward_see);
          k_output=solv_line_k(center,0,center_change,0,&b,1,0);
      }
     else if(type==5)
      {
          if(left_dot>right_dot)
           {
               for(i=single_in;i<left_dot;i+=2)
                {
                    center[center_dot][0]=RST0[left_line[i][0] * Y_MAX + left_line[i][1]];
                    center[center_dot++][1]=RST1[left_line[i][0] * Y_MAX + left_line[i][1]];
                }
           }
          else
           {
               for(i=single_in;i<right_dot;i+=2)
                {
                    center[center_dot][0]=RST0[right_line[i][0] * Y_MAX + right_line[i][1]];
                    center[center_dot++][1]=RST1[right_line[i][0] * Y_MAX + right_line[i][1]];
                }
           }
          k_output=1.1*solv_line_k(center,0,center_dot,0,&b,1,0);
      }
     // send_line_other(UART0,2,(float)(type));
#endif
     
		   // LED_ON(led0,led_off);
#if  1//�ֶθ��ٵ㣬б�ʿ���  K_B������ǿ�����������㷨
     if((type==0)||(type==6))
      {
          if(left_dot>right_dot) get_roll_left(R_main,forward_see);
          else get_roll_right(R_main,forward_see);
          k_output=solv_line_k2(center,0,center_dot,0,&b,1,0);
      }
     else if((type==1)||(type==2))
      {
          uint16 change_angle=0;
          if(left_dot>right_dot) get_roll_left(R_main,forward_see);
          else get_roll_right(R_main,forward_see);
          
          if(change_angle=change_get2(center,center_dot))
              center_2=Delete_In_Corner(center,center_dot,change_angle);
          else angle_type=0;
          // k_output=solv_line_k(center_2.dot,0,center_2.num*2/3,0,&b,1,0);
          if(angle_type!=0)
           {
               if(!identify_angle())
                {
                    right_dot=change_right_dot+1;
                    left_dot=change_left_dot+1;
                    type4_line();
                    if(left_dot>right_dot) get_roll_left(R_main,forward_see);
                    else get_roll_right(R_main,forward_see);
                    k_output=solv_line_k2(center,0,center_dot,0,&b,1,0);
                   // send_line_other(UART0,2,1000);
                }
               else
                {
                    k_output=solv_line_k2(center,0,center_dot,0,&b,1,0);
                    if(angle_type==1)  {k_output=20;b=130;} 
                    else if(angle_type==2) {k_output=-20;b=130;} 
                    else if(angle_type==3) {k_output=0;b=140;}
                    else if(angle_type==4){k_output=0;b=120;}
                    
                    
                    //send_line_other(UART0,2,8000);
                }
           }
          else 
           {
               k_output=solv_line_k2(center,0,center_dot,0,&b,1,0);
              // if((type==1)&&(k_output<0)) k_output/=-1;
              // if((type==2)&&(k_output>0)) k_output/=-1;
                   
           }
      }
     else if((type==3)||(type==4))
      {
	  error_flag=22;
          if(left_dot>right_dot) get_roll_left(R_main,forward_see);
          else get_roll_right(R_main,forward_see);
          k_output=solv_line_k2(center,0,center_dot,0,&b,1,0);
      }
     else if(type==5)
      {
          if(left_dot>right_dot)
           {
               for(i=single_in;i<left_dot;i+=2)
                {
                    center[center_dot][0]=RST0[left_line[i][0] * Y_MAX + left_line[i][1]];
                    center[center_dot++][1]=RST1[left_line[i][0] * Y_MAX + left_line[i][1]];
                }
           }
          else
           {
               for(i=single_in;i<right_dot;i+=2)
                {
                    center[center_dot][0]=RST0[right_line[i][0] * Y_MAX + right_line[i][1]];
                    center[center_dot++][1]=RST1[right_line[i][0] * Y_MAX + right_line[i][1]];
                }
           }
          k_output=solv_line_k2(center,0,center_dot,0,&b,1,0);
      }
     else if(type==7)
      {
          float k1,k2,b1,b2;
          get_roll_left(R_main,forward_see);k1=solv_line_k2(center,0,center_dot,0,&b1,1,0);
          get_roll_right(R_main,forward_see);k2=solv_line_k2(center,0,center_dot,0,&b2,1,0);
          k_output=(k1+k2)/2;b=(b1+b2)/2;
      }
     // send_line_other(UART0,2,(float)(type));
     // an=atan(k_output)/pi*180;
#if 0
     uint32 abs_float;
     if(k_output>0) abs_float=(uint32)(k_output*1000);
     else abs_float=(uint32)(1000*k_output/-1);
     if(40000/abs_float+20>150) get_servo=b+150*k_output;
     else get_servo=b+(40000/abs_float+20)*k_output;
#endif
     get_servo=b+for_ward*k_output;

     
     /*memcpy(CircleDot.dot,ave_line,sizeof(uint16)*2);
     memcpy(&CircleDot.dot[2],&ave_line[ave_dot-1],sizeof(uint16)*2);
     memcpy(&CircleDot.dot[1],&ave_line[ave_dot/2],sizeof(uint16)*2);
     CircleDot.num = 3;
     CircleR = GetCircleR(CircleDot);
     CircleR = 1.0/CircleR*1000.0;*/
     
#endif
     
     //k_output=solv_line_k(center,0,center_change*2/3,0,&b,1,0);
               
     //   UART_SS(UART0,"control_3 ");
     //?��?????��D��?����?����???��P

     //   UART_SS(UART0,"control_4 ");
     
     /*}
     else 
     {
     LED_ON(led1,led_on);
     for(i=0;i<dot_num;i++)
     {
     center[i][0]=(RST0[left_line[left_dot*i/dot_num][0]*230+left_line[left_dot*i/dot_num][1]]+RST0[right_line[right_dot*i/dot_num][0]*230+right_line[right_dot*i/dot_num][1]])/2;
     center[i][1]=(RST1[left_line[left_dot*i/dot_num][0]*230+left_line[left_dot*i/dot_num][1]]+RST1[right_line[right_dot*i/dot_num][0]*230+right_line[right_dot*i/dot_num][1]])/2;
 }
     k_output=solv_line_k(center,1,19,0,&b,1,0);
 }*/
     
     /*else 
     {
     LED_ON(led1,led_on);
     for(i=0;i<dot_num;i++)
     {
     center[i][0]=(RST0[left_line[left_dot/dot_num*i][0]*180+left_line[left_dot/dot_num*i][1]]+RST0[right_line[right_dot/dot_num*i][0]*180+right_line[right_dot/dot_num*i][1]])/2;
     center[i][1]=(RST1[left_line[left_dot/dot_num*i][0]*180+left_line[left_dot/dot_num*i][1]]+RST1[right_line[right_dot/dot_num*i][0]*180+right_line[right_dot/dot_num*i][1]])/2;
 }
     k_output=solv_line_k(center,1,15,0);
 }*/
 }

uint8 single_mode()
 {
     uint8 left_flag = 0, right_flag = 0,  left = 3, right = Y_MAX - 3;
     uint8 i, j,k;
     uint16 single_start_left[50][2]={0},single_start_right[50][2]={0},single_left_time=0,single_right_time=0;
     for (i = start; (!(right_flag)); i+=2) 
      {
          left_flag = 0; right_flag = 0;
          for (j =10; j <Y_MAX-10; j++)
           {
               if ((date[i][j + 1] < threshold_left) && (date[i][j + 2]<threshold_left) && (date[i][j] >threshold_left))
                {
                    right = j;
                    left_flag = 1;
                    break;
                }
               left_flag = 0;
           }
          if (left_flag)
           {
               for (j; j < Y_MAX-10; j++)
                {
                    if ((date[i][j + 1] > threshold_right) && (date[i][j + 2] > threshold_right) && (date[i][j] < threshold_right))
                     {
                         left = j;
                         if(left<right+4*scale)
                             right_flag = 1;
                         break;
                     }
                    right_flag = 0;
                }
           }
          if (right_flag)
           {
               single_start_left[single_left_time][0]=single_start_right[single_right_time][0]=i;
               single_start_left[single_left_time++][1]=left;single_start_right[single_right_time++][1]=right;
               right_flag=0;
               if(single_right_time>4) 
                {
                    for (k = 1; k<3; k++)
                     {
                         if ((single_start_right[single_right_time - k][1] + scale<single_start_right[single_right_time - k - 1][1]) || (single_start_right[single_right_time - k - 1][1] + scale<single_start_right[single_right_time - k][1]))
                          {
                              right_flag = 0; break;
                          }
                         else right_flag = 1;
                     }
                }
               if(right_flag)
                {
                    right_line[right_dot][0] = single_start_right[single_right_time-1][0]; right_line[right_dot++][1] =single_start_right[single_right_time-1][1];
                    left_line[left_dot][0] = single_start_left[single_left_time-1][0]; left_line[left_dot++][1] =single_start_left[single_left_time-1][1]; 
                    scan_mode=1;type=5;
                   return 1;
                    break;
                }
           }
          if(i>30)
           {
               left_dot = 1; right_dot = 1;
               start_single = 0; return 0;
           }
      }
 }

void two_wile_mode()
 {
     scan_mode=0;
     uint8 start_left[100][2] = { 0 },start_right[100][2] = {0};//�����ҵ�����ʼ��͵���
     start_left[0][0]=3;start_left[0][1]=3;start_right[0][0]=3;start_right[0][1]=Y_MAX-3;
     uint8 left_flag, right_flag = 0, left_i, right_i, k, left, right, i,j,dark_times=0;
     uint16 start_left_dot=1,start_right_dot=1;    
     left_line[0][0] = 3; left_line[0][1] = 3; right_line[0][0] = 3; right_line[0][1] = Y_MAX - 3;
      left_line[1][0] = 3; left_line[1][1] = 3; right_line[1][0] = 3; right_line[1][1] = Y_MAX - 3;
     left_dot = 1; right_dot = 1; left_flag = 0; right_flag = 0;
     for (left_i = right_i = start; !((left_flag) && (right_flag));)   //?������|?��?????DD?��?����?��??�졧?DD?��?��???
      {
          left = 3; right = Y_MAX - 3;
          if (!left_flag)
           {
               for (j =3; j<Y_MAX-50; j++)
				{
					if ((date[left_i][j] >threshold_left) && (date[left_i][j - 2] <threshold_left) && (date[left_i][j - 1]<threshold_left))
                     {
                         left = j;
                         start_left[start_left_dot][0] = left_i; start_left[start_left_dot][1] = left; start_left_dot++;
                         if (start_left_dot>4)
                          {
                              for (k = 1; k<3; k++)
                               {
                                   if ((start_left[start_left_dot - k][1] + scale<start_left[start_left_dot - k - 1][1]) || (start_left[start_left_dot - k - 1][1] + scale<start_left[start_left_dot - k][1]))
                                    {
                                        left_flag = 0; break;
                                    }
                                   else left_flag = 1;
                               }
                          }
                         break;
                     }
					else left_flag = 0;
				}
               left_i+=2;
           }
          if (!right_flag)
           {
               for (j =Y_MAX-3; j >50; j--)
				{
					if ((date[right_i][j] >threshold_right) && (date[right_i][j + 1] <threshold_right) && (date[right_i][j + 2] <threshold_right) )
                     {
                         right = j;
                         start_right[start_right_dot][0] = right_i; start_right[start_right_dot][1] = right; start_right_dot++;
                         if (start_right_dot>4)
                          {
                              for (k = 1; k<3; k++)
                               {
                                   if ((start_right[start_right_dot - k][1] + scale<start_right[start_right_dot - k - 1][1]) || (start_right[start_right_dot - k - 1][1] + scale<start_right[start_right_dot - k][1]))
                                    {
                                        right_flag = 0; break;
                                    }
                                   else right_flag = 1;
                               }
                          }
                         break;
                     }
					else right_flag = 0;
				}
               right_i+=2;
           }
          if ((left_i>80) && (right_i>80))
           {
               left_lose = 1; right_lose = 1;
               //right_line[right_dot][0] = start_right[start_right_dot - 1][0]; right_line[right_dot][1] = start_right[start_right_dot - 1][1];
               //left_line[left_dot][0] = start_left[start_left_dot - 1][0]; left_line[left_dot][1] = start_left[start_left_dot - 1][1];
               for(i=3;i<Y_MAX-3;i++)
                {
                    if(date[10][i]<(threshold_left+threshold_right)/2) dark_times++;
                }
               if(dark_times>Y_MAX/2) 
                   type=4;
               else type = 3; 
               left_last = 3; right_last = Y_MAX - 3;
               scan_mode = 1; 
               //left_dot++;right_dot++;
               break;
           }
          else if ((left_i>80) && right_flag){
              left_lose = 1;
              left_last = 3; 
              if((start_right[start_right_dot - 1][0]>30)&&(start_right[start_right_dot - 1][1]>30))
               {
                   right_lose=1;right_last = Y_MAX-3; 
               }
              else
               {
                   right_line[right_dot][0] = start_right[start_right_dot - 1][0]; right_line[right_dot][1] = start_right[start_right_dot - 1][1]; right_last = right_line[right_dot][1]; right_dot++; 
               }
              //left_line[left_dot][0] = start_left[start_left_dot - 1][0]; left_line[left_dot][1] = start_left[start_left_dot - 1][1];left_dot++;
              break;
          }
          else if (left_flag && (right_i>80))
           {
               right_lose = 1;
               //right_line[right_dot][0] = start_right[start_right_dot - 1][0]; right_line[right_dot][1] = start_right[start_right_dot - 1][1];right_dot++;
               right_last = Y_MAX-3; 
               if((start_left[start_left_dot - 1][0]>30)&&(start_left[start_left_dot - 1][1]>30))
                {
                    left_lose=1;left_last=3;
                }
               else
                {
                    left_line[left_dot][0] = start_left[start_left_dot - 1][0]; left_line[left_dot][1] = start_left[start_left_dot - 1][1]; left_last = left_line[left_dot][1]; left_dot++;
                }
               break;
           }
          else if (left_flag&&right_flag)
           {
               if((start_right[start_right_dot - 1][0]>30)&&(start_left[start_left_dot - 1][0]>30))
                {
                    left_lose=1;right_lose=1;
                    left_dot = 2; right_dot = 2;
                    type = 3; scan_mode = 1; break;
                }
               if(start_right[start_right_dot - 1][1]<start_left[start_left_dot - 1][1])
                {
                    if((start_right[start_right_dot - 1][1]+start_left[start_left_dot - 1][1])/2>Y_MAX/2)
                     {
                         right_line[right_dot][0] = start_right[start_right_dot - 1][0]; right_line[right_dot][1] = start_right[start_right_dot - 1][1]; right_last = right_line[right_dot][1]; right_dot++;
                     }
                    else 
                     {
                         left_line[left_dot][0] = start_left[start_left_dot - 1][0]; left_line[left_dot][1] = start_left[start_left_dot - 1][1]; left_last = left_line[left_dot][1]; left_dot++;     
                     }
                }
               else
                {
                    right_line[right_dot][0] = start_right[start_right_dot - 1][0]; right_line[right_dot][1] = start_right[start_right_dot - 1][1]; right_last = right_line[right_dot][1]; right_dot++;
                    left_line[left_dot][0] = start_left[start_left_dot - 1][0]; left_line[left_dot][1] = start_left[start_left_dot - 1][1]; left_last = left_line[left_dot][1]; left_dot++;
                }
               break;

           }
      }
 }
void hang_scan()
 {
     //UART_SS(UART0,"hangsao_begain");
     error_flag=right_dot;
     int16 i;
     uint16 threshold_left_times=0,threshold_right_times=0; 
     uint16 sum_threshold_w=0,sum_threshold_d=0,w_times=0,d_times=0;//������ֵ����
     uint8 change_left = 0, change_right = 0; uint8 error_times_right=0, error_times_left=0;//����û�ҵ���Ĵ��������˾��˳�
     uint16 left_i, right_i, left_j, right_j, left_end_flag = 1, right_end_flag = 1;//��ʾ�߽��Ƿ񵽴�
     uint16 root1, root2, left_end=0, right_end=0,left_flag,right_flag,left,right;
     error_flag=11;
     for (left_i = left_line[left_dot - 1][0], right_i = right_line[right_dot - 1][0], left_j = left_line[left_dot - 1][1], right_j = right_line[right_dot - 1][1]; (!(change_left&&change_right))&&(left_end_flag || right_end_flag);)
      {
          if (!change_left)//����Ҳ�����ֹͣ
           {
	       error_flag=12;
               root1 = left_line[left_dot - 1][1];  left_flag = 0;
               //	root1=left_line[left_dot-1][1]-left_line[left_dot-2][1]+left_line[left_dot-1][1];
               if (date[left_i][root1] >threshold_left)//��������Ǹ�Ϊ�׵㣬������
                {
                    if (root1<scale) left_end = 3; else left_end = root1 - scale;
                    for (left_j = root1; left_j >= left_end; left_j--)
                     {
                         if ((date[left_i][left_j - 2] <threshold_left) && (date[left_i][left_j - 1] <threshold_left))
                          {
                              left = left_j;
                              error_times_left = 0;
                              left_flag = 1;//��ʾ�ɼ������Ե
                              // ����ֵ
#ifdef Th_Open1
                              threshold_left_times++;
                              if(threshold_left_times>=Th_change_time)
                               {
                                   threshold_left_times=0;
                                   if((left>5)&&(left<Y_MAX-5))
                                    {
                                        if (date[left_i][left + 1]>date[left_i][left]) threshold_max = date[left_i][left + 1];
                                        else threshold_max = date[left_i][left];
                                        if (date[left_i][left + 2]>threshold_max) threshold_max = date[left_i][left + 2];
                                        
                                        if (date[left_i][left - 2]<date[left_i][left - 1]) threshold_min = date[left_i][left - 2];
                                        else threshold_min = date[left_i][left - 1];
                                        if (date[left_i][left - 3]<threshold_min)  threshold_min = date[left_i][left - 3];
                                        threshold_left = (threshold_max + threshold_min) / 2;}
                               }
#endif
                              
#ifdef Th_Open2
                              threshold_left_times++;
                              if(threshold_left_times>=Th_change_time)
                               { 
                                   threshold_left_times=0;sum_threshold_d=sum_threshold_w=0;d_times=w_times=0;
                                   if((left>5)&&(left<Y_MAX-5))
                                    {
                                        for(i=0;i<10;i++)
                                         {
                                             if(date[left_i][left-5+i]<threshold_left) 
                                              {
                                                  sum_threshold_d+=date[left_i][left-5+i];
                                                  d_times++;
                                              }
                                             else
                                              {
                                                  sum_threshold_w+=date[left_i][left-5+i];
                                                  w_times++;
                                              }
                                         }
                                        threshold_left=(sum_threshold_d/d_times+sum_threshold_w/w_times)/2;
                                        auto_threshold_left[auto_left_times++]=threshold_left;
                                    }
                               }
                              
#endif
                              left_line[left_dot][0] = left_i; left_line[left_dot][1] = left; left_dot++;
                              break;
                          }
                         left_flag = 0;
                     }
                    if (left_flag == 0) error_times_left++;
                    if (error_times_left >= 3) change_left = 1;
                }
               else
                {
                    if (root1 + scale>Y_MAX - 3) left_end = Y_MAX - 3; else left_end = root1 + scale;
                    for (left_j = root1; left_j<left_end; left_j++)
                     {
                         if ((date[left_i][left_j + 2] >threshold_left) && (date[left_i][left_j + 1] >threshold_left))
                          {
                              left = left_j + 1;
                              error_times_left = 0;
                              left_flag = 1;//��ʾ�ɼ������Ե
                              //threshold_left = (date[left_i][left] + date[left_i][left - 1]) / 2;
#ifdef Th_Open1
                              threshold_left_times++;
                              if(threshold_left_times>=Th_change_time)
                               {
                                   threshold_left_times=0;
                                   if((left>5)&&(left<Y_MAX-5))
                                    {
                                        if (date[left_i][left + 1]>date[left_i][left]) threshold_max = date[left_i][left + 1];
                                        else threshold_max = date[left_i][left];
                                        if (date[left_i][left + 2]>threshold_max) threshold_max = date[left_i][left + 2];
                                        
                                        if (date[left_i][left - 2]<date[left_i][left - 1]) threshold_min = date[left_i][left - 2];
                                        else threshold_min = date[left_i][left - 1];
                                        if (date[left_i][left - 3]<threshold_min)  threshold_min = date[left_i][left - 3];
                                        threshold_left = (threshold_max + threshold_min) / 2;}
                               }
#endif
                              
#ifdef Th_Open2
                              threshold_left_times++;
                              if(threshold_left_times>=Th_change_time)
                               { 
                                   threshold_left_times=0;sum_threshold_d=sum_threshold_w=0;d_times=w_times=0;
                                   if((left>5)&&(left<Y_MAX-5))
                                    {
                                        for(i=0;i<10;i++)
                                         {
                                             if(date[left_i][left-5+i]<threshold_left) 
                                              {
                                                  sum_threshold_d+=date[left_i][left-5+i];
                                                  d_times++;
                                              }
                                             else
                                              {
                                                  sum_threshold_w+=date[left_i][left-5+i];
                                                  w_times++;
                                              }
                                         }
                                        threshold_left=(sum_threshold_d/d_times+sum_threshold_w/w_times)/2;
                                         auto_threshold_left[auto_left_times++]=threshold_left;
                                    }
                               }
                              
#endif
                              left_line[left_dot][0] = left_i; left_line[left_dot][1] = left; left_dot++;
                              break;
                          }
                         left_flag = 0;
                     }
                    if (left_flag == 0) error_times_left++;
                    if (error_times_left >= 3) change_left = 1;
                }
               left_i++;
	       error_flag=12;
           }
          if (!change_right)//�ұ��� ������ֹͣ
           {
	       error_flag=13;
               root2 = right_line[right_dot - 1][1]; right_flag = 0;
               //	root2=right_line[right_dot-1][1]-right_line[right_dot-2][1]+right_line[right_dot-1][1];
               if (date[right_i][root2] >threshold_right)//��������Ǹ�Ϊ�׵㣬������
                {
                    if (root2 + scale>Y_MAX - 3) right_end = Y_MAX - 3; else right_end = root2 + scale;
                    for (right_j = root2; right_j<right_end; right_j++)
                     {
                         if ((date[right_i][right_j + 2] <threshold_right) && (date[right_i][right_j + 1] <threshold_right))
                          {
                              right = right_j;
                              error_times_right = 0;
                              right_flag = 1;///��ʾ�ɼ����ұ�Ե
                              //  threshold_right = (date[right_i][right] + date[right_i][right + 1]) / 2;
                              
#ifdef Th_Open1
                              threshold_right_times++;
                              if(threshold_right_times>=Th_change_time)
                               {
                                   threshold_right_times=0;
                                   if((right>5)&&(right<Y_MAX-5))
                                    {
                                        if (date[right_i][right - 1]>date[right_i][right]) threshold_max = date[right_i][right - 1];
                                        else threshold_max = date[right_i][right];
                                        if (date[right_i][right - 2]>threshold_max) threshold_max = date[right_i][right - 2];
                                        if (date[right_i][right + 2]<date[right_i][right + 1]) threshold_min = date[right_i][right + 2];
                                        else threshold_min = date[right_i][right + 1];
                                        if (date[right_i][right + 3]<threshold_min) threshold_min = date[right_i][right + 3];
                                        threshold_right = (threshold_min + threshold_max) / 2;
                                    }}
#endif
                              
#ifdef Th_Open2
                              threshold_right_times++;
                              if(threshold_right_times>=Th_change_time)
                               { 
                                   threshold_right_times=0;sum_threshold_d=sum_threshold_w=0;d_times=w_times=0;
                                   if((right>5)&&(right<Y_MAX-5))
                                    {
                                        for(i=0;i<10;i++)
                                         {
                                             if(date[right_i][right-4+i]<threshold_right)
                                              {
                                                  sum_threshold_d+=date[right_i][right-4+i];
                                                  d_times++;
                                              }
                                             else 
                                              {
                                                  sum_threshold_w+=date[right_i][right-4+i];
                                                  w_times++;
                                              }
                                         }
                                         threshold_right=(sum_threshold_d/d_times+sum_threshold_w/w_times)/2;
                                         auto_threshold_right[auto_right_times++]=threshold_right;
                                    }
                               }
                              
#endif
                              
                              
                              right_line[right_dot][0] = right_i; right_line[right_dot][1] = right; right_dot++;
                              break;
                          }
                         right_flag = 0;
                     }
                    if (right_flag == 0) error_times_right++; if (error_times_right >= 3) change_right = 1;
                }
               else
                {
                    if (root2<scale) right_end = 3; else right_end = root2 - scale;
                    for (right_j = root2; right_j>right_end; right_j--)
                     {
                         if ((date[right_i][right_j - 2] >threshold_right) && (date[right_i][right_j - 1] >threshold_right))
                          {
                              right = right_j - 1;
                              error_times_right = 0;
                              right_flag = 1;//��ʾ�ɼ������Ե
                              // threshold_right = (date[right_i][right] + date[right_i][right + 1]) / 2;
#ifdef Th_Open1
                              threshold_right_times++;
                              if(threshold_right_times>=Th_change_time)
                               {
                                   threshold_right_times=0;
                                   if((right>5)&&(right<Y_MAX-5))
                                    {
                                        if (date[right_i][right - 1]>date[right_i][right]) threshold_max = date[right_i][right - 1];
                                        else threshold_max = date[right_i][right];
                                        if (date[right_i][right - 2]>threshold_max) threshold_max = date[right_i][right - 2];
                                        if (date[right_i][right + 2]<date[right_i][right + 1]) threshold_min = date[right_i][right + 2];
                                        else threshold_min = date[right_i][right + 1];
                                        if (date[right_i][right + 3]<threshold_min) threshold_min = date[right_i][right + 3];
                                        threshold_right = (threshold_min + threshold_max) / 2;
                                    }}
#endif
                              
#ifdef Th_Open2
                              threshold_right_times++;
                              if(threshold_right_times>=Th_change_time)
                               { 
                                   threshold_right_times=0;sum_threshold_d=sum_threshold_w=0;d_times=w_times=0;
                                   if((right>5)&&(right<Y_MAX-5))
                                    {
                                        for(i=0;i<10;i++)
                                         {
                                             if(date[right_i][right-4+i]<threshold_right)
                                              {
                                                  sum_threshold_d+=date[right_i][right-4+i];
                                                  d_times++;
                                              }
                                             else 
                                              {
                                                  sum_threshold_w+=date[right_i][right-4+i];
                                                  w_times++;
                                              }
                                         }
                                         threshold_right=(sum_threshold_d/d_times+sum_threshold_w/w_times)/2;
                                         auto_threshold_right[auto_right_times++]=threshold_right;
                                    }
                               }
                              
#endif
                              right_line[right_dot][0] = right_i; right_line[right_dot][1] = right; right_dot++;
                              break;
                          }
                         right_flag = 0;
                     }
                    if (right_flag == 0)
                        error_times_right++;
                    if (error_times_right >= 3)
                        change_right = 1;
                }
               right_i++;
	       error_flag=14;
	   }
	  left_end_flag = ((left_i>=2) && (left_i<=X_MAX - 2) && (left_j>=2) && (left_j<=Y_MAX - 2));//���˱߽磬��0
	  right_end_flag = ((right_i>=2) && (right_i<X_MAX - 2) && (right_j>=2) && (right_j<=Y_MAX - 2));
	  if(left_end_flag==0) change_left=1;
	  if(right_end_flag==0) change_right=1;
	  error_flag=15;
      }
     //UART_SS(UART0,"hang_scan() ok!!!");
 }
void type_get()
 {
     uint8 left_white_time = 0, left_dark_time = 0;uint8 k=0;
     uint8 right_white_time = 0, right_dark_time = 0;
     uint16 i, j, left_l_dir, right_l_dir;
     uint16 single_left_ok, single_right_ok, test_single_hang, test_single_line, single_times = 0, single_left[50][2], single_right[50][2],temp=0;
     change_times++;
     if((left_dot>100)&&(right_dot>100)) {type=6;return  ;}
     else if((left_dot>120)||(right_dot>120))  {type=7;return;}
     uint16 dark_times=0,white_times=0,dark_hang=0;
	  float sub_float=0;uint16 hang_set=0;
	  if(left_line[left_dot-1][1]!=right_line[right_dot-1][1])
       {
           sub_float=(float)(right_line[right_dot-1][0]-left_line[left_dot-1][0])/(float)(right_line[right_dot-1][1]-left_line[left_dot-1][1]);
       }
      dark_times=0;white_times=0;
	  dark_hang=left_line[left_dot-1][0]+5;
      for(j=left_line[left_dot-1][1];j<right_line[right_dot-1][1];j++)
       {
	       hang_set=dark_hang+sub_float*(j-left_line[left_dot-1][1]);
           if(date[hang_set][j]<(threshold_right+threshold_left)/2) dark_times++;
           else white_times++;
       }
      if(dark_times>white_times)
       {  type = 4;//������������
        return ;
       }
          //UART_SS(UART0,"type=4 ok!!!");
     //if (change_times>2) successed = 0;
     for (i = 0; i < 20; i+=2)
      {
          for (j = 0; j < scale; j++)
              if (date[left_line[left_dot - 1][0] + i][left_line[left_dot - 1][1] + j - 2] >threshold_left)
                  left_white_time++;
              else left_dark_time++;
      }
     if (left_white_time > left_dark_time) left_l_dir = 0; else left_l_dir = 1;
     for (i = 0; i < 20; i+=2)
      {
          for (j = 0; j < scale; j++)
              if (date[right_line[right_dot - 1][0] + i][right_line[right_dot - 1][1] + j - 2] >threshold_right)
                  right_white_time++;
              else right_dark_time++;
      }
     if (right_white_time > right_dark_time) right_l_dir = 1; else right_l_dir = 0;
     
     if (left_l_dir&right_l_dir) { type = 1; scan_mode = 1;return; }//����ֱ�ǻ������������ƫ
     else if (!(left_l_dir || right_l_dir)) { type = 2;scan_mode = 1; return; }//����ֱ�ǻ���������Сƫ
     else if ((!left_l_dir) && (right_l_dir))//������������ʮ��
      {
          //���ƣ���ֹ����ܽ���ʱ��
          //if((left_line[left_dot-1][0]>right_line[right_dot-1][0]+60)||(right_line[right_dot-1][0]>left_line[left_dot-1][0]+60)) {type=0;return 0;}
          single_left_ok = 0; single_right_ok = 0;
          if (left_line[left_dot - 1][0]>right_line[right_dot - 1][0]) test_single_hang = left_line[left_dot - 1][0];
          else test_single_hang = right_line[right_dot - 1][0];
          //test_single_hang=(left_line[left_dot - 1][0]+right_line[right_dot - 1][0])/2;
          for (i = test_single_hang; (i <= test_single_hang + 30)&&(i<X_MAX); i++)
           {
               single_left_ok = 0; single_right_ok = 0;
               for (test_single_line = left_line[left_dot - 1][1]; test_single_line <= right_line[right_dot - 1][1]; test_single_line++)
                {
                    if ((!single_left_ok) &&(date[i][test_single_line]>(threshold_left + threshold_right) / 2) && (date[i][test_single_line+2]<(threshold_left + threshold_right) / 2) && (date[i][test_single_line + 1] <(threshold_left + threshold_right) / 2))
                     {
                         temp= test_single_line;
                         single_left_ok = 1;//��������������
                     }
                    if ((single_left_ok) &&(date[i][test_single_line] <(threshold_left + threshold_right) / 2) &&  (date[i][test_single_line+2] >(threshold_left + threshold_right) / 2) && (date[i][test_single_line + 1] >(threshold_left + threshold_right) / 2))
                     {
                         if(test_single_line< temp + 4 * scale)
                          {
                              single_right_ok=1;
                              single_right[single_times][0] = i;//����ȷ��
                              single_right[single_times][1] = test_single_line;
                              single_left[single_times][0] = i;
                              single_left[single_times++][1] = temp;
                              break;
                          }
                         else single_right_ok=0;
                     }
                }
               if(single_right_ok)
                {
                    single_right_ok=0;
                    if(single_times>4) 
                     {
                         for (k = 1; k<3; k++)
                          {
                              if ((single_right[single_times - k][1] + scale<single_right[single_times - k - 1][1]) || (single_right[single_times - k - 1][1] + scale<single_right[single_times - k][1]))
                               {
                                   single_right_ok = 0; break;
                               }
                              else single_right_ok = 1;
                          }
                     }
                }
               if(single_right_ok) break;
           }
          if (single_right_ok)
           {//��������ת��������ɨ��
               left_line[left_dot][0] = single_right[single_times-1][0]; left_line[left_dot][1] = single_right[single_times-1][1];  left_dot++;
               right_line[right_dot][0] = single_left[single_times-1][0]; right_line[right_dot][1] = single_left[single_times-1][1]; right_dot++;
                type = 5;//���������˵���
                single_get_hang=single_right[single_times-1][0]+20;
                if(single_right[single_times-1][0]<120)
                 { start_single = 1; }
              // if(left_line[left_dot-1][0]<40)  {start_single = 1; R_main = 0;}
              //UART_SS(UART0,"type=5 ok!!!");
           }
          else
           {
               type = 3;//������ʮ��
               if(left_line[left_dot-1][0]<30)
                {start_single = 0; R_main = R_large;}
               //UART_SS(UART0,"type=3 ok!!!");
           }
      }
     else return ;

 }
void type1_line()
 {
     uint16 i;
     uint16 threshold_left_times=0,threshold_right_times=0; 
     uint16 sum_threshold_w=0,sum_threshold_d=0,w_times=0,d_times=0;//������ֵ����
     uint16 left_i, right_i, left_j, right_j, root1, root2, left_end, right_end, left, right, error_times_left = 0, error_times_right=0;
     uint8 left_end_flag = 1, right_end_flag = 1, left_flag=0, right_flag=0, successed_left = 1,successed_right=1;
     left_i = left_line[left_dot - 1][0], right_i = right_line[right_dot - 1][0], left_j = left_line[left_dot - 1][1], right_j = right_line[right_dot - 1][1];
     //if(left_i<3) left_i=3; else if(left_i>X_MAX-3) left_i=X_MAX-3;
     //if(right_i<3) right_i=3;else if(right_i>X_MAX-3) right_i=X_MAX-3;
     for (; (successed_left||successed_right) && (left_end_flag || right_end_flag);)
      {
          if (left_end_flag)	//���û���꣬������
           {
               root1 = left_line[left_dot - 1][0]; left_flag = 0;
               //root1=left_line[left_dot-1][0]-left_line[left_dot-2][0]+left_line[left_dot-1][0];
               if (date[root1][left_j] > threshold_left)//��������Ǹ�Ϊ�׵㣬������
                {
                    if (root1 < scale) left_end = 3; else left_end = root1 + scale;
                    for (left_i = root1; left_i <= left_end; left_i++)
                     {
                         if ((date[left_i + 2][left_j] <threshold_left) && (date[left_i + 1][left_j] <threshold_left))
                          {
                              left = left_i;
                              error_times_left = 0;
                              left_flag = 1;//��ʾ�ɼ������Ե
                              //threshold_left = (date[left][left_j] + date[left + 1][left_j]) / 2;
#ifdef Th_Open1
                              threshold_left_times++;
                              if(threshold_left_times>=Th_change_time)
                               {
                                   threshold_left_times=0;
                                   if((left>5)&&(left<X_MAX-5))
                                    {
                                        if (date[left - 1][left_j]>date[left][left_j]) threshold_max = date[left - 1][left_j];
                                        else threshold_max = date[left][left_j];
                                        if (date[left - 2][left_j]>threshold_max) threshold_max = date[left - 2][left_j];
                                        
                                        if (date[left + 2][left_j] < date[left + 1][left_j]) threshold_min = date[left + 2][left_j];
                                        else threshold_min = date[left + 1][left_j];
                                        if (date[left + 3][left_j]<threshold_min)  threshold_min = date[left + 3][left_j];
                                        threshold_left = (threshold_min + threshold_max) / 2;
                                    }}
#endif
                              
#ifdef Th_Open2
                              threshold_left_times++;
                              if(threshold_left_times>=Th_change_time)
                               { 
                                   threshold_left_times=0;sum_threshold_d=sum_threshold_w=0;d_times=w_times=0;
                                   if((left>5)&&(left<X_MAX-5))
                                    {
                                        for(i=0;i<10;i++)
                                         {
                                             if(date[left-4+i][left_j]<threshold_left)
                                              {
                                                  sum_threshold_d+=date[left-4+i][left_j];
                                                  d_times++;
                                              }
                                             else 
                                              {
                                                  sum_threshold_w+=date[left-4+i][left_j];
                                                  w_times++;
                                              }
                                         }
                                        threshold_left=(sum_threshold_d/d_times+sum_threshold_w/w_times)/2;
                                         auto_threshold_left[auto_left_times++]=threshold_left;
                                    }
                               }
#endif
                              
                              
                              left_line[left_dot][0] = left; left_line[left_dot][1] = left_j; left_dot++;
                              break;
                          }
                         left_flag = 0;
                     }
                }
               else
                {
                    if (root1 + scale>Y_MAX - 3) left_end = Y_MAX - 3; else left_end = root1 - scale;
                    for (left_i = root1; left_i >= left_end; left_i--)
                     {
                         if ((date[left_i - 2][left_j] > threshold_left) && (date[left_i - 1][left_j] > threshold_left))
                          {
                              left = left_i - 1;
                              error_times_left = 0;
                              left_flag = 1;//��ʾ�ɼ������Ե
                              //threshold_left = (date[left][left_j] + date[left + 1][left_j]) / 2;
#ifdef Th_Open1
                              threshold_left_times++;
                              if(threshold_left_times>=Th_change_time)
                               {
                                   threshold_left_times=0;
                                   if((left>5)&&(left<X_MAX-5))
                                    {
                                        if (date[left - 1][left_j]>date[left][left_j]) threshold_max = date[left - 1][left_j];
                                        else threshold_max = date[left][left_j];
                                        if (date[left - 2][left_j]>threshold_max) threshold_max = date[left - 2][left_j];
                                        
                                        if (date[left + 2][left_j] < date[left + 1][left_j]) threshold_min = date[left + 2][left_j];
                                        else threshold_min = date[left + 1][left_j];
                                        if (date[left + 3][left_j]<threshold_min)  threshold_min = date[left + 3][left_j];
                                        threshold_left = (threshold_min + threshold_max) / 2;
                                    }}
#endif
                              
#ifdef Th_Open2
                              threshold_left_times++;
                              if(threshold_left_times>=Th_change_time)
                               { 
                                   threshold_left_times=0;sum_threshold_d=sum_threshold_w=0;d_times=w_times=0;
                                   if((left>5)&&(left<X_MAX-5))
                                    {
                                        for(i=0;i<10;i++)
                                         {
                                             if(date[left-4+i][left_j]<threshold_left)
                                              {
                                                  sum_threshold_d+=date[left-4+i][left_j];
                                                  d_times++;
                                              }
                                             else 
                                              {
                                                  sum_threshold_w+=date[left-4+i][left_j];
                                                  w_times++;
                                              }
                                         }
                                        threshold_left=(sum_threshold_d/d_times+sum_threshold_w/w_times)/2;
                                        auto_threshold_left[auto_left_times++]=threshold_left;
                                    }
                               }
#endif
                              left_line[left_dot][0] = left; left_line[left_dot][1] = left_j; left_dot++;
                              break;
                          }
                         left_flag = 0;
                     }
                }
               if (left_flag == 0) error_times_left++; if (error_times_left > 5) successed_left = 0;
               left_j++;
           }
          if (right_end_flag)//�ұ�û���꣬������
           {
               root2 = right_line[right_dot - 1][0]; right_flag = 0;
               //	root2=right_line[right_dot-1][0]-right_line[right_dot-2][0]+right_line[right_dot-1][0];
               if (date[root2][right_j] < threshold_right)//��������Ǹ�Ϊ�ڵ㣬������
                {
                    if (root2 < scale) right_end = 3; else right_end = root2 + scale;
                    for (right_i = root2; right_i < right_end; right_i++)
                     {
                         if ((date[right_i + 2][right_j] > threshold_right) && (date[right_i + 1][right_j] > threshold_right))
                          {
                              right = right_i + 1;
                              error_times_right = 0;
                              right_flag = 1;//��ʾ�ɼ������Ե
                              //threshold_right = (date[right][right_j] + date[right - 1][right_j]) / 2;
#ifdef Th_Open1
                              threshold_right_times++;
                              if(threshold_right_times>=Th_change_time)
                               {
                                   threshold_right_times=0;
                                   if((right>5)&&(right<X_MAX-5))
                                    {
                                        if (date[right + 1][right_j] > date[right][right_j]) threshold_max = date[right + 1][right_j];
                                        else threshold_max = date[right][right_j];
                                        if (date[right + 2][right_j] > threshold_max) threshold_max = date[right + 2][right_j];
                                        
                                        if (date[right - 2][right_j] < date[right - 1][right_j]) threshold_min = date[right - 2][right_j];
                                        else threshold_min = date[right - 1][right_j];
                                        if (date[right - 3][right_j]<threshold_min)  threshold_min = date[right - 3][right_j];
                                        threshold_right = (threshold_max + threshold_min) / 2;
                                    }}
#endif
#ifdef Th_Open2
                              threshold_right_times++;
                              if(threshold_right_times>=Th_change_time)
                               { 
                                   threshold_right_times=0;sum_threshold_d=sum_threshold_w=0;d_times=w_times=0;
                                   if((right>5)&&(right<X_MAX-5))
                                    {
                                        for(i=0;i<10;i++)
                                         {
                                             if(date[right-5+i][right_j]<threshold_right)
                                              {
                                                  sum_threshold_d+=date[right-5+i][right_j];
                                                  d_times++;
                                              }
                                             else
                                              {
                                                  sum_threshold_w+=date[right-5+i][right_j];
                                                  w_times++;
                                              }
                                         }
                                        threshold_right=(sum_threshold_d/d_times+sum_threshold_w/w_times)/2;
                                        auto_threshold_right[auto_right_times++]=threshold_right;
                                    }
                               }
#endif
                              right_line[right_dot][0] = right; right_line[right_dot][1] = right_j; right_dot++;
                              break;
                          }
                         right_flag = 0;
                     }
                }
               else
                {
                    if (root2 + scale>Y_MAX - 3) right_end = Y_MAX - 3; else right_end = root2 - scale;
                    for (right_i = root2; right_i > right_end; right_i--)
                     {
                         if ((date[right_i - 1][right_j]<threshold_right) && (date[right_i - 2][right_j]<threshold_right))
                          {
                              right = right_i;
                              error_times_right = 0;
                              right_flag = 1;//��ʾ�ɼ������Ե
                              // threshold_right = (date[right][right_j] + date[right - 1][right_j]) / 2;
#ifdef Th_Open1
                              threshold_right_times++;
                              if(threshold_right_times>=Th_change_time)
                               {
                                   threshold_right_times=0;
                                   if((right>5)&&(right<X_MAX-5))
                                    {
                                        if (date[right + 1][right_j] > date[right][right_j]) threshold_max = date[right + 1][right_j];
                                        else threshold_max = date[right][right_j];
                                        if (date[right + 2][right_j] > threshold_max) threshold_max = date[right + 2][right_j];
                                        
                                        if (date[right - 2][right_j] < date[right - 1][right_j]) threshold_min = date[right - 2][right_j];
                                        else threshold_min = date[right - 1][right_j];
                                        if (date[right - 3][right_j]<threshold_min)  threshold_min = date[right - 3][right_j];
                                        threshold_right = (threshold_max + threshold_min) / 2;
                                    }}
#endif
#ifdef Th_Open2
                              threshold_right_times++;
                              if(threshold_right_times>=Th_change_time)
                               { 
                                   threshold_right_times=0;sum_threshold_d=sum_threshold_w=0;d_times=w_times=0;
                                   if((right>5)&&(right<X_MAX-5))
                                    {
                                        for(i=0;i<10;i++)
                                         {
                                             if(date[right-5+i][right_j]<threshold_right)
                                              {
                                                  sum_threshold_d+=date[right-5+i][right_j];
                                                  d_times++;
                                              }
                                             else
                                              {
                                                  sum_threshold_w+=date[right-5+i][right_j];
                                                  w_times++;
                                              }
                                         }
                                        threshold_right=(sum_threshold_d/d_times+sum_threshold_w/w_times)/2;
                                        auto_threshold_right[auto_right_times++]=threshold_right;
                                    }
                               }
#endif
                              right_line[right_dot][0] = right; right_line[right_dot][1] = right_j; right_dot++;
                              break;
                          }
                         right_flag = 0;
                     }
                }
               if (right_flag == 0) error_times_right++; if (error_times_right > 5) successed_right = 0;
               right_j++;
           }
          left_end_flag = ((left_i>=2) && (left_i<=X_MAX - 2) && (left_j>=2) && (left_j<=Y_MAX - 2));//��?��?��???��???0
          right_end_flag = ((right_i>=2) && (right_i<=X_MAX - 2) && (right_j>=2) && (right_j<=Y_MAX - 2));
          if(left_end_flag==0 )  successed_left=0;
	   if(right_end_flag==0 )  successed_right=0;
      }
     //UART_SS(UART0,"type1 ok!!!");
 }

void type2_line()
 {
     uint16 i;
     uint16 threshold_left_times=0,threshold_right_times=0;     
     uint16 sum_threshold_w=0,sum_threshold_d=0,w_times=0,d_times=0;//������ֵ����
     uint16 left_i, right_i, left_j, right_j, root1, root2, left_end, right_end, left, right, error_times_left = 0, error_times_right = 0;
     uint8 left_end_flag = 1, right_end_flag = 1, left_flag = 0, right_flag = 0, successed_left = 1,successed_right=1;
     left_i = left_line[left_dot - 1][0], right_i = right_line[right_dot - 1][0], left_j = left_line[left_dot - 1][1], right_j = right_line[right_dot - 1][1];
     if(left_i<3) left_i=3; else if(left_i>X_MAX-3) left_i=X_MAX-3;
     if(right_i<3) right_i=3;else if(right_i>X_MAX-3) right_i=X_MAX-3;
     for (; (successed_left||successed_right) && (left_end_flag || right_end_flag);)
      {
          if (left_end_flag)	//���û���꣬������
           {
               root1 = left_line[left_dot - 1][0]; left_flag = 0;
               //root1=left_line[left_dot-1][0]-left_line[left_dot-2][0]+left_line[left_dot-1][0];
               if (date[root1][left_j] >threshold_left)//��������Ǹ�Ϊ�׵㣬������
                {
                    if (root1<scale) left_end = scale; else left_end = root1 - scale;
                    for (left_i = root1; left_i>left_end; left_i--)
                     {
                         if ((date[left_i][left_j]>threshold_left) && (date[left_i - 1][left_j]<threshold_left) && (date[left_i - 2][left_j]<threshold_left))
                          {
                              left = left_i;
                              error_times_left = 0;
                              left_flag = 1;//��ʾ�ɼ������Ե
                              //threshold_left = (date[left][left_j] + date[left - 1][left_j]) / 2;
#ifdef Th_Open1
                              threshold_left_times++;
                              if(threshold_left_times>=Th_change_time)
                               {
                                   threshold_left_times=0;
                                   if((left>5)&&(left<X_MAX-5))
                                    {
                                        if (date[left + 1][left_j]>date[left][left_j]) threshold_max = date[left + 1][left_j];
                                        else threshold_max = date[left][left_j];
                                        if (date[left + 2][left_j]>threshold_max) threshold_max = date[left + 2][left_j];
                                        
                                        if (date[left - 2][left_j]<date[left - 1][left_j]) threshold_min = date[left - 2][left_j];
                                        else threshold_min = date[left - 1][left_j];
                                        if (date[left - 3][left_j]<threshold_min)  threshold_min = date[left - 3][left_j];
                                        threshold_left = (threshold_min + threshold_max) / 2;
                                    }
                               }
#endif
#ifdef Th_Open2
                              threshold_left_times++;
                              if(threshold_left_times>=Th_change_time)
                               { 
                                   threshold_left_times=0;sum_threshold_d=sum_threshold_w=0;d_times=w_times=0;
                                   if((left>5)&&(left<X_MAX-5))
                                    {
                                        for(i=0;i<10;i++)
                                         {
                                             if(date[left-5+i][left_j]<threshold_left)
                                              {
                                                 sum_threshold_d+=date[left-5+i][left_j];
                                                 d_times++;
                                              }
                                             else
                                              {
                                                  sum_threshold_w+=date[left-5+i][left_j];
                                                 w_times++;
                                              }
                                         }
                                        threshold_left=(sum_threshold_d/d_times+sum_threshold_w/w_times)/2;
                                        auto_threshold_left[auto_left_times++]=threshold_left;
                                    }
                               }
#endif
                              left_line[left_dot][0] = left; left_line[left_dot][1] = left_j; left_dot++;
                              break;
                          }
                         left_flag = 0;
                     }
                }
               else
                {
                    if (root1 + scale>Y_MAX - 3) left_end = Y_MAX - 3; else left_end = root1 + scale;
                    for (left_i = root1; left_i<left_end; left_i++)
                     {
                         if ((date[left_i][left_j] <threshold_left) && (date[left_i + 2][left_j] >threshold_left) && (date[left_i + 1][left_j] >threshold_left))
                          {
                              left = left_i + 1;
                              error_times_left = 0;
                              left_flag = 1;//��ʾ�ɼ������Ե
                              // threshold_left = (date[left][left_j] + date[left - 1][left_j]) / 2;
#ifdef Th_Open1
                              threshold_left_times++;
                              if(threshold_left_times>=Th_change_time)
                               {
                                   threshold_left_times=0;
                                   if((left>5)&&(left<X_MAX-5))
                                    {
                                        if (date[left + 1][left_j]>date[left][left_j]) threshold_max = date[left + 1][left_j];
                                        else threshold_max = date[left][left_j];
                                        if (date[left + 2][left_j]>threshold_max) threshold_max = date[left + 2][left_j];
                                        
                                        if (date[left - 2][left_j]<date[left - 1][left_j]) threshold_min = date[left - 2][left_j];
                                        else threshold_min = date[left - 1][left_j];
                                        if (date[left - 3][left_j]<threshold_min)  threshold_min = date[left - 3][left_j];
                                        threshold_left = (threshold_min + threshold_max) / 2;
                                    }
                               }
#endif
#ifdef Th_Open2
                              threshold_left_times++;
                              if(threshold_left_times>=Th_change_time)
                               { 
                                   threshold_left_times=0;sum_threshold_d=sum_threshold_w=0;d_times=w_times=0;
                                   if((left>5)&&(left<X_MAX-5))
                                    {
                                        for(i=0;i<10;i++)
                                         {
                                             if(date[left-5+i][left_j]<threshold_left)
                                              {
                                                 sum_threshold_d+=date[left-5+i][left_j];
                                                 d_times++;
                                              }
                                             else
                                              {
                                                  sum_threshold_w+=date[left-5+i][left_j];
                                                 w_times++;
                                              }
                                         }
                                        threshold_left=(sum_threshold_d/d_times+sum_threshold_w/w_times)/2;
                                          auto_threshold_left[auto_left_times++]=threshold_left;
                                    }
                               }
#endif
                              left_line[left_dot][0] = left; left_line[left_dot][1] = left_j; left_dot++;
                              break;
                          }
                         left_flag = 0;
                     }
                }
               if (left_flag == 0) error_times_left++; if (error_times_left>5) 
                   successed_left = 0;
                   left_j--;
           }
          if (right_end_flag)//�ұ�û���꣬������
           {
               root2 = right_line[right_dot - 1][0]; right_flag = 0;
               //	root2=right_line[right_dot-1][0]-right_line[right_dot-2][0]+right_line[right_dot-1][0];
               if (date[root2][right_j] <threshold_right)//��������Ǹ�Ϊ�ڵ㣬������
                {
                    if (root2<scale) right_end = 3; else right_end = root2 - scale;
                    for (right_i = root2; right_i>right_end; right_i--)
                     {
                         if ((date[right_i][right_j] <threshold_right) && (date[right_i - 2][right_j] >threshold_right) && (date[right_i - 1][right_j]>threshold_right))
                          {
                              right = right_i - 1;
                              error_times_right = 0;
                              right_flag = 1;//��ʾ�ɼ������Ե
                              // threshold_right = (date[right][right_j] + date[right + 1][right_j]) / 2;
#ifdef Th_Open1
                              threshold_right_times++;
                              if(threshold_right_times>=Th_change_time)
                               {
                                   threshold_right_times=0;
                                   if((right>5)&&(right<X_MAX-5))
                                    {
                                        if (date[right - 1][right_j]>date[right][right_j]) threshold_max = date[right - 1][right_j];
                                        else threshold_max = date[right][right_j];
                                        if (date[right - 2][right_j]>threshold_max) threshold_max = date[right - 2][right_j];
                                        
                                        if (date[right + 2][right_j]<date[right + 1][right_j]) threshold_min = date[right + 2][right_j];
                                        else threshold_min = date[right + 1][right_j];
                                        if (date[right + 3][right_j]<threshold_min)  threshold_min = date[right + 3][right_j];
                                        threshold_right = (threshold_max + threshold_min) / 2;
                                    }}
#endif
#ifdef Th_Open2
                              threshold_right_times++;
                              if(threshold_right_times>=Th_change_time)
                               { 
                                   threshold_right_times=0;sum_threshold_d=sum_threshold_w=0;d_times=w_times=0;
                                   if((right>5)&&(right<X_MAX-5))
                                    {
                                        for(i=0;i<10;i++)
                                         {
                                             if(date[right-4+i][right_j]<threshold_right)
                                              {
                                                  sum_threshold_d+=date[right-4+i][right_j];
                                                  d_times++;
                                              }
                                             else
                                              {
                                                   sum_threshold_w+=date[right-4+i][right_j];
                                                  w_times++;
                                              }
                                         }
                                        threshold_right=(sum_threshold_d/d_times+sum_threshold_w/w_times)/2;
                                          auto_threshold_right[auto_right_times++]=threshold_right;
                                    }
                               }
#endif
                              right_line[right_dot][0] = right; right_line[right_dot][1] = right_j; right_dot++;
                              break;
                          }
                         right_flag = 0;
                     }
                }
               else
                {
                    if (root2 + scale>Y_MAX - 3) right_end = Y_MAX - 3; else right_end = root2 + scale;
                    for (right_i = root2; right_i<right_end; right_i++)
                     {
                         if ((date[right_i][right_j] >threshold_right) && (date[right_i + 1][right_j] <threshold_right) && (date[right_i + 2][right_j] <threshold_right))
                          {
                              right = right_i;
                              error_times_right = 0;
                              right_flag = 1;//��ʾ�ɼ������Ե
                              // threshold_right = (date[right][right_j] + date[right + 1][right_j]) / 2;
#ifdef Th_Open1
                              threshold_right_times++;
                              if(threshold_right_times>=Th_change_time)
                               {
                                   threshold_right_times=0;
                                   if((right>5)&&(right<X_MAX-5))
                                    {
                                        if (date[right - 1][right_j]>date[right][right_j]) threshold_max = date[right - 1][right_j];
                                        else threshold_max = date[right][right_j];
                                        if (date[right - 2][right_j]>threshold_max) threshold_max = date[right - 2][right_j];
                                        
                                        if (date[right + 2][right_j]<date[right + 1][right_j]) threshold_min = date[right + 2][right_j];
                                        else threshold_min = date[right + 1][right_j];
                                        if (date[right + 3][right_j]<threshold_min)  threshold_min = date[right + 3][right_j];
                                        threshold_right = (threshold_max + threshold_min) / 2;
                                    }}
#endif
#ifdef Th_Open2
                              threshold_right_times++;
                              if(threshold_right_times>=Th_change_time)
                               { 
                                   threshold_right_times=0;sum_threshold_d=sum_threshold_w=0;d_times=w_times=0;
                                   if((right>5)&&(right<X_MAX-5))
                                    {
                                        for(i=0;i<10;i++)
                                         {
                                             if(date[right-4+i][right_j]<threshold_right)
                                              {
                                                  sum_threshold_d+=date[right-4+i][right_j];
                                                  d_times++;
                                              }
                                             else
                                              {
                                                   sum_threshold_w+=date[right-4+i][right_j];
                                                  w_times++;
                                              }
                                         }
                                        threshold_right=(sum_threshold_d/d_times+sum_threshold_w/w_times)/2;
                                        auto_threshold_right[auto_right_times++]=threshold_right;
                                    }
                               }
#endif
                              right_line[right_dot][0] = right; right_line[right_dot][1] = right_j; right_dot++;
                              break;
                          }
                         right_flag = 0;
                     }
                }
               if (right_flag == 0) error_times_right++; 
               if (error_times_right>5) 
                   successed_right = 0;
               right_j--;
           }
          left_end_flag = ((left_i>=2) && (left_i<=X_MAX - 2) && (left_j>=2) && (left_j<=Y_MAX - 2));//��?��?��???��???0
          right_end_flag = ((right_i>=2) && (right_i<=X_MAX - 2) && (right_j>=2) && (right_j<=Y_MAX - 2));
      	if(left_end_flag==0) successed_left=0;
	if(right_end_flag==0) successed_right=0;
      }
     // UART_SS(UART0,"type2 ok!!!");
 }
void type3_line()
 {
     float dot_sub_left, dot_sub_right;
     uint16 ten_left_times=0,ten_right_times=0;
     uint16 left_i_stay,left_j_stay, right_i_stay,right_j_stay,left_i=left_line[left_dot-1][0],right_i=right_line[right_dot-1][0];
     uint16 add_flag=0;
     uint8 i,j,ones_ok = 0, ten_left_ok = 0, ten_right_ok = 0,left_once_ok, right_once_ok;
     uint16 ten_hang, ten_end=Y_MAX-5, ten_start=5, left_10[500][2]={0},right_10[500][2]={0};
     int left_j,right_j;
     uint8 scan_=15;
     if (left_line[left_dot - 1][0]>right_line[right_dot - 1][0]) ten_hang = left_line[left_dot - 1][0] + scan_;
     else ten_hang = right_line[right_dot - 1][0] + scan_;
     ten_end = right_line[right_dot - 1][1];ten_start = left_line[left_dot - 1][1];
     if (!ones_ok)//�жϲ����Ƿ�ɹ�
      {
          for (ten_hang; (!(ten_left_ok&ten_right_ok)) && (ten_hang<X_MAX - 3); ten_hang += scan_)
           {
               left_once_ok = right_once_ok = 0;
               for (j = ten_start;(!ten_left_ok) && (!left_once_ok) && (j<ten_end); j++)
                {
                    if ( (date[ten_hang][j - 1] <threshold_left) && (date[ten_hang][j - 2] <threshold_left) && (date[ten_hang][j] >threshold_left) && (date[ten_hang][j + 1] >threshold_left))
                     {
                         left_once_ok = 1;
                         scan_=2;
                         left_10[ten_left_times][1] = j;
                         left_10[ten_left_times++][0] = ten_hang;
                         if (ten_left_times>7)  
                          {
                              for (i = 1; i<6; i++)
                               {
                                   if ((left_10[ten_left_times - i][1] + scale<left_10[ten_left_times - i - 1][1]) || (left_10[ten_left_times - i - 1][1] + scale<left_10[ten_left_times - i][1]))
                                    {
                                        ten_left_ok = 0; break;
                                    }
                                   else  ten_left_ok = 1;
                               }
                          }
                     }
                }
               for (j = ten_end;(!ten_right_ok) && (!right_once_ok) &&(j>ten_start); j--)
                {
                    if ( (date[ten_hang][j + 3] <threshold_right) && (date[ten_hang][j + 2] <threshold_right) && (date[ten_hang][j + 1] <threshold_right) && (date[ten_hang][j - 1]>threshold_right) && (date[ten_hang][j - 2]>threshold_right))
                     {
                         right_once_ok = 1;
                         scan_=1;
                         right_10[ten_right_times][1] = j;
                         right_10[ten_right_times++][0] = ten_hang;
                         if (ten_right_times>7)
                          {
                              for (i = 1; i<6; i++)
                               {
                                   if ((right_10[ten_right_times - i][1] + scale<right_10[ten_right_times - i - 1][1]) || (right_10[ten_right_times - i - 1][1] + scale<right_10[ten_right_times - i][1]))
                                    {
                                        ten_right_ok = 0; break;
                                    }
                                   else  ten_right_ok = 1;
                               }
                          }
                     }
                }
           }
          ones_ok = 1;//����һ���Թ�
           //����������ҵ�~��ֱ�����¿�ʼ
          //�ж��Ƿ񵽴�ʮ�ֵ�
          /*if(ten_left_ok&ten_right_ok)
          {
      }*/
          if (right_10[ten_right_times - 1][1]<left_10[ten_left_times - 1][1])
           {
               if ((left_lose == 1) && (right_lose == 0)) {ten_left_ok = 0;right_line[1][0]=0;right_line[1][1]=Y_MAX-3;}
               if ((left_lose == 0) && (right_lose == 1)) {ten_right_ok = 0;left_line[1][0]=0,left_line[1][1]=3;}
               if((left_lose==0)&&(right_lose==0)){ten_left_ok=ten_right_ok=0;}
           }
	   if((ten_left_ok==0)&&(ten_right_ok==0)) {type=0;return ;}
          if(left_lose&&right_lose&&ten_left_ok&&ten_right_ok) {ten_left_ok=ten_right_ok=0;add_flag=1;}
        // if(left_lose == 1) ten_left_ok=0;
          //if(right_lose == 1)ten_right_ok=0;//��ʧ������ 
          if(ten_left_ok||ten_right_ok)
           {
               if ((left_lose == 1) && (right_lose == 0)) {right_dot/=2;}
               else if ((right_lose == 1) && (left_lose == 0)) {left_dot/=2;}
               else  if((!right_lose)&&(!left_lose)) {right_dot/=2;left_dot/=2;}
           }
          
          if((left_lose==1)&&(right_lose==0)) ten_left_ok=0;
          if((right_lose==1)&&(left_lose==0))ten_right_ok=0;
          if (ten_left_ok)
           {
               left_i=left_line[left_dot-1][0];
               dot_sub_left = ((((float)left_10[ten_left_times - 1][1] - (float)left_line[left_dot - 1][1]))) / (((float)left_10[ten_left_times - 1][0] - (float)left_line[left_dot - 1][0]));
               left_j_stay = left_line[left_dot - 1][1];
               left_i_stay=left_line[left_dot - 1][0];
               for (left_i; left_i<left_10[ten_left_times - 1][0]; left_i++)
                {
                    left_line[left_dot][0] = left_i;
                    left_line[left_dot][1] = left_j_stay + (int16)(dot_sub_left*(left_i - left_i_stay));
                    left_dot++;
                }
               left_line[left_dot][0]= left_10[ten_left_times - 1][0]; left_line[left_dot][1] = left_10[ten_left_times - 1][1]; left_dot++;
               
           }
          if (ten_right_ok)
           {
               right_i=right_line[right_dot-1][0];
               dot_sub_right = (float)(right_10[ten_right_times - 1][1] - right_line[right_dot - 1][1]) / (float)(right_10[ten_right_times - 1][0] - right_line[right_dot - 1][0]);
               right_j_stay = right_line[right_dot - 1][1];
               right_i_stay=right_line[right_dot-1][0];
               for (right_i; right_i<right_10[ten_right_times - 1][0]; right_i++)
                {
                    right_line[right_dot][0] = right_i;
                    right_line[right_dot][1] = right_j_stay + (int16)(dot_sub_right*(right_i - right_i_stay));
                    right_dot++;
                }
               right_line[right_dot][0] = right_10[ten_right_times - 1][0]; right_line[right_dot][1] = right_10[ten_right_times - 1][1]; right_dot++;
               
           }
          if(ten_left_ok||ten_right_ok) hang_scan();
          if(add_flag)
           {
               dot_sub_left=1/simple_k_solve( left_10, 1,7,1);
               dot_sub_right=1/simple_k_solve( right_10, 1,7,1);
                //if(dot_sub_left==0) dot_sub_left=0.01;
              //  dot_sub_left=1/dot_sub_left;
                
               // right_10[8][0]=right_10[0][0];right_10[8][1]=left_10[0][1];
               // right_10[7][0]=right_10[1][0];right_10[7][1]=left_10[1][1];
               // right_10[9][0]=right_10[2][0];right_10[9][1]=left_10[2][1];
                
               // if(dot_sub_right==0) dot_sub_right=0.01;
               // dot_sub_right=1/dot_sub_right;
                
              //dot_sub_left=(float)(left_10[ten_left_times-1][1]-left_10[ten_left_times-5][1])/(float)(left_10[ten_left_times-1][0]-left_10[ten_left_times-5][0]);
              //dot_sub_right=(float)(right_10[ten_right_times-1][1]-right_10[ten_right_times-5][1])/(float)(right_10[ten_right_times-1][0]-right_10[ten_right_times-5][0]);
               
                
                //dot_sub_left(left_10,ten_left_times - 1,ten_left_times - 6,0,&b,1,1);
                //dot_sub_right(right_10,ten_right_times - 1,ten_right_times - 6,0,&b,1,1);
               for(left_i=3;left_i<left_10[ten_left_times-6][0];left_i++)
                {
                    left_j=left_10[ten_left_times-6][1]-dot_sub_left*(left_10[ten_left_times-6][0]-left_i);
                    if((left_j>3)&&(left_j<Y_MAX-3))
                     {
                         left_line[left_dot][0]=left_i;
                         left_line[left_dot++][1]=left_j;
                     }
                }
                 for(right_i=3;right_i<right_10[ten_right_times-6][0];right_i++)
                {
                    right_j=right_10[ten_right_times-6][1]-dot_sub_right*(right_10[ten_right_times-6][0]-right_i);
                    if((right_j>3)&&(right_j<Y_MAX-3))
                     {
                        right_line[right_dot][0]=right_i;
                         right_line[right_dot++][1]=right_j;
                     }
                }
                left_line[left_dot][0]= left_10[ten_left_times - 6][0]; left_line[left_dot][1] = left_10[ten_left_times - 6][1]; left_dot++;
               right_line[right_dot][0] = right_10[ten_right_times - 6][0]; right_line[right_dot][1] = right_10[ten_right_times - 6][1]; right_dot++;
                hang_scan();
           }
          scan_mode = 0;
      }
 }
uint8  type4_line()
 {
     error_flag=1;
     float dot_sub_left = 0, dot_sub_right = 0;
     uint8 ones_ok = 0, left_once_ok=0,right_once_ok=0,angle_left_ok = 0, angle_right_ok = 0, angle_ok_times = 0,
     angle_left_times = 0, angle_right_times = 0, angle_ok=0;
     int16 i, j;
     uint16 angle_hang, angle_lie=0, left_angle_j, left_angle[20][2]={0}, right_angle_j, right_angle[20][2]={0}, left_i_stay,right_i_stay,left_j_stay,right_j_stay;
     uint16 left_i = left_line[left_dot - 1][0], right_i = right_line[right_dot - 1][0];
     if (left_line[left_dot - 1][0]>right_line[right_dot - 1][0]) angle_hang = left_line[left_dot - 1][0] + 15;
     else angle_hang = right_line[right_dot - 1][0] + 15;
     angle_lie = (left_line[left_dot - 1][1] + right_line[right_dot - 1][1]) / 2;
     // UART_SS(UART0,"tpye4__test1");
#if   1
     if((left_line[left_dot-1][0]+15>right_line[right_dot-1][0])&&(right_line[right_dot-1][0]+15>left_line[left_dot-1][0])&&(left_line[left_dot-1][1]+15>right_line[right_dot-1][1])&&(right_line[right_dot-1][1]+15>left_line[left_dot-1][1]))
      { 
          ones_ok=1;
          uint16 add_hang=left_line[left_dot-1][0]+20,add_lie=left_line[left_dot-1][1];
          uint16 add[10][2]={0},add_times=0,add_left_ok=0,add_right_ok=0;
          for(i=add_hang;(!add_left_ok)&&(i<add_hang+10);i++)
           {
               for(j=add_lie;(j<add_lie+50)&&(j<Y_MAX-3);j++)
                {
                    if((date[i][j]<threshold)&&(date[i][j+1]>threshold)&&(date[i][j+2]>threshold))
                        
                     {add[add_times][0]=i;
                        add[add_times++][1]=j;
                        break;
                     }
                }
                 if(add_times>5) 
                     add_left_ok=1;
           }
          for(i=add_hang;(!add_left_ok)&&(!add_right_ok)&&(i<add_hang+10);i++)
           {
               for(j=add_lie;(j>add_lie-50)&&(j>3);j--)
                {
                    if((date[i][j]<threshold)&&(date[i][j-1]>threshold)&&(date[i][j-2]>threshold))
                        
                     {add[add_times][0]=i;
                        add[add_times++][1]=j;
                        break;
                     }
                }
                 if(add_times>5) 
                     add_right_ok=1;
           }
          if((add_left_ok)&&(left_dot>3))
           {
	       if(add[add_times-1][0] != left_line[left_dot - 1][0])
               dot_sub_left = (float)(add[add_times-1][1] - left_line[left_dot - 1][1]) / (float)(add[add_times-1][0] - left_line[left_dot - 1][0]);
              else dot_sub_left=0;
		   left_j_stay = left_line[left_dot - 1][1];
               left_i_stay = left_line[left_dot - 1][0];
               for (left_i; left_i<add[add_times-1][0]; left_i++)
                {
                    left_line[left_dot][0] = left_i;
                    left_line[left_dot][1] = left_j_stay + (int16)(dot_sub_left*(left_i - left_i_stay));
                    left_dot++;
                }
               left_line[left_dot][0]  = add[add_times-1][0]; left_line[left_dot][1]  = add[add_times-1][1]; left_dot++;
                right_dot=2;
		
		error_flag=2;
               return 1;
           }  
          if((add_right_ok)&&(right_dot>3))
           {
	       if(add[add_times-1][0] != right_line[right_dot - 1][0])
               dot_sub_right = (float)(add[add_times-1][1] - right_line[right_dot - 1][1]) / (float)(add[add_times-1][0] - right_line[right_dot - 1][0]);
              else dot_sub_right=0;
	       right_j_stay = right_line[right_dot - 1][1];
               right_i_stay = right_line[right_dot - 1][0];
               for (right_i; right_i<add[add_times-1][0]; right_i++)
                {
                    right_line[right_dot][0] = right_i;
                    right_line[right_dot][1] = right_j_stay + (int16)(dot_sub_right*(right_i - right_i_stay));
                    right_dot++;
                }
               right_line[right_dot][0]  = add[add_times-1][0]; right_line[right_dot][1]  = add[add_times-1][1]; right_dot++;
               left_dot=2; 
	       error_flag=3;
               return 1;
           }
      }
#endif
     while (!ones_ok)//�жϲ����Ƿ�ɹ�
      {
	   // LED_ON(led0,led_on);
          for (angle_hang; (angle_hang < X_MAX - 3)&&(angle_lie>5); angle_hang += 5)
           {
               for (j = 0; j<10; j++)
                {
                    if ((date[angle_hang][angle_lie + j - 5] >(threshold_right + threshold_left) / 2))//�����ѵ�����֮��İ���
                     {
                         angle_ok_times++;
                     }
                }
               if (angle_ok_times>5) { angle_ok = 1; break; }
               else angle_ok = 0;
           }
          //   UART_SS(UART0,"tpye4__test2");
          ones_ok = 1;//����������һ�Σ��˳�
	  angle_left_ok=0;angle_right_ok=0;
          if (angle_ok)	//������������ߣ��ұ߽��˳���ֱ��ģʽ
           {
               for(angle_hang;(!(angle_left_ok&&angle_right_ok))&&(angle_hang<X_MAX-3);angle_hang+=2)
                {
                    left_once_ok=right_once_ok=0;
                    for (left_angle_j = angle_lie; (!angle_left_ok) &&(!left_once_ok)&& (left_angle_j>3); left_angle_j--)
                     {
                         if ((date[angle_hang][left_angle_j] >threshold) && (date[angle_hang][left_angle_j - 2] <threshold) && (date[angle_hang][left_angle_j - 1] <threshold))
                          {
                              left_once_ok=1;
                              left_angle[angle_left_times][1] = left_angle_j;
                              left_angle[angle_left_times++][0] = angle_hang;
                              if (angle_left_times>5)
                               {
                                   for (i = 1; i<3; i++)
                                    {
                                        if ((left_angle[angle_left_times - i][1] + scale<left_angle[angle_left_times - i - 1][1]) || (left_angle[angle_left_times - i - 1][1] + scale<left_angle[angle_left_times - i][1]))
                                         {
                                             angle_left_ok = 0; break;
                                         }
                                        else  angle_left_ok = 1;
                                    }
                               }
                          }
                     }
                    //       UART_SS(UART0,"tpye4__test3");
                    for (right_angle_j = angle_lie; (!angle_right_ok) &&(!right_once_ok)&& (right_angle_j<Y_MAX - 3); right_angle_j++)
                     {
                           left_once_ok=right_once_ok=0;
                         if ((date[angle_hang][right_angle_j] >threshold) && (date[angle_hang][right_angle_j + 2] <threshold) && (date[angle_hang][right_angle_j + 1] <threshold))
                          {
                              right_once_ok=1;
                              right_angle[angle_right_times][1] = right_angle_j;
                              right_angle[angle_right_times++][0] = angle_hang;
                              if (angle_right_times>5)
                               {
                                   for (i = 1; i<3; i++)
                                    {
                                        if ((right_angle[angle_right_times - i][1] + scale<right_angle[angle_right_times - i - 1][1]) || (right_angle[angle_right_times - i - 1][1] + scale<right_angle[angle_right_times - i][1]))
                                         {
                                             angle_right_ok = 0; break;
                                         }
                                        else  angle_right_ok = 1;
                                    }
                               }
                          }
                     }
                    //     UART_SS(UART0,"tpye4__test4");
                }
               if (angle_left_ok||angle_right_ok)
                {
                    if(angle_left_ok)
                     {
                         if(left_angle[angle_left_times-1][0] != left_line[left_dot - 1][0])
                             dot_sub_left = (float)(left_angle[angle_left_times-1][1] - left_line[left_dot - 1][1]) / (float)(left_angle[angle_left_times-1][0] - left_line[left_dot - 1][0]);
                         else dot_sub_left=0;
                         left_j_stay = left_line[left_dot - 1][1];
                         left_i_stay = left_line[left_dot - 1][0];
                         
                         for (left_i; left_i<left_angle[angle_left_times-1][0]; left_i++)
                          {
                              left_line[left_dot][0] = left_i;
                              left_line[left_dot][1] = left_j_stay + (int16)(dot_sub_left*(left_i - left_i_stay));
                              left_dot++;
                          }
                         left_line[left_dot][0]  = left_angle[angle_left_times-1][0]; left_line[left_dot][1]  = left_angle[angle_left_times-1][1]; left_dot++;
                         
                     }
                    if(angle_right_ok)
                     {
                         if(right_angle[angle_right_times-1][0] != right_line[right_dot - 1][0])
                             dot_sub_right = (float)(right_angle[angle_right_times-1][1] - right_line[right_dot - 1][1]) / (float)(right_angle[angle_right_times-1][0] - right_line[right_dot - 1][0]);
                         else dot_sub_right=0;
                         right_i_stay = right_line[right_dot - 1][0];
                         right_j_stay = right_line[right_dot - 1][1];
                         for (right_i; right_i<right_angle[angle_right_times-1][0]; right_i++)
                          {
                              right_line[right_dot][0] = right_i;
                              right_line[right_dot][1] = right_j_stay + (int16)(dot_sub_right*(right_i - right_i_stay));
                              right_dot++;
                          }
                         //	type = 0; scan_mode_left = 0; scan_mode_right = 0;		//׼��ֱ������
                         right_line[right_dot][0]  = right_angle[angle_right_times-1][0]; right_line[right_dot][1]  = right_angle[angle_right_times-1][1]; right_dot++;
                     }
                    return 1;
                    //    UART_SS(UART0,"tpye4__test6");
                }
               else {error_flag=5;return 0;}
           }
          /*else          //����ֱ���˳�
          {
          successed = 0;
      }*/
      }
     //UART_SS(UART0,"type4 ok!!!");
 }
void type6_line()
 {
     uint16 i,j,Obstacle_in_right=0,Obstacle_in_left=0,Obstacle_ok=0;
     uint16 Obstacle=0,Obstacle_times=0,Obstacle_ok_times,Obstacle_site=Y_MAX_OUT/2;
     for(i=0;i<130;i+=5)
      {
             Obstacle_times=0;   Obstacle=0;         
          for(j=left_line[i][1];j<right_line[i][1];j+=3)
           {

               if((date[i][j-1]<(threshold_left+threshold_right)/2)&&(date[i][j]<threshold)&&(date[i][j+1]<(threshold_left+threshold_right)/2))
                {
                    Obstacle+=j;
                    Obstacle_times++;
                }
               
           }
          if(Obstacle_times>=5)
           {
               Obstacle_ok++;
               Obstacle_site=Obstacle/Obstacle_times;
               if(Obstacle_site>(left_line[i][1]+right_line[i][1])/2)
                   Obstacle_in_right++;
               else Obstacle_in_left++;
           }
      }
     if(Obstacle_ok>=3)
      {
          R_main=R_large*2/5;type=6;
          if(Obstacle_in_right>Obstacle_in_left) {right_dot/=2;}
          else {left_dot/=2;}
      }
     else {R_main=R_large;type=7;}
 }

float k4, e, k_test[30];
void get_roll_right(uint32 R,uint16 forward_look)
 {
     ave_dot=0;
     int16 i = 0, cen_i, cen_j, dot_def = 0, end_dot;
     uint16 sum_hang[30][2]={0},sum_lie[35][2]={0},sum_dot_h[30]={0},sum_dot_l[30]={0},ave_i=0;
     float k=0, e1, prop = 1, B;
     //if(change_right_dot!=0) {prop=(float)change_right_dot/(float)right_dot;     dot_def=(right_dot-change_right_dot)/(dot_num*(1-prop));}
     for (i = 6; i<change_right_dot; i+=3)
      {
          if((i>change_right_dot-5)&&(i<change_right_dot))
           {
                k = solv_line_k(right_line, i - 5, i , 1,&B,1,0);
                e1 = atan(k);
               //e=e1;
               //k_test[i]=k;
               // cen_i = RST0[right_line[i][0] * 230 + right_line[i][1]] + R;
               //cen_j = RST1[right_line[i][0] * 230 + right_line[i][1]] + R;
               cen_i = RST0[right_line[i][0] * Y_MAX + right_line[i][1]] + R*sin(pi - e1);
               cen_j = RST1[right_line[i][0] * Y_MAX + right_line[i][1]] + R*cos(pi - e1);

               if ((cen_i<X_MAX_OUT) && (cen_j<Y_MAX_OUT)  && (cen_j>0))
                {
                    center[center_dot][0] = cen_i;
                    center[center_dot++][1] = cen_j;
                }
           }
          //k=1*solv_line_k(right_line,right_dot*i/dot_num-3,right_dot*i/dot_num+3);
          else 
           {
               k = solv_line_k(right_line, i - 5, i + 5, 1,&B,2,0);
               // k4=k;
               e1 = atan(k);
               //e=e1;
               //k_test[i]=k;
               // cen_i = RST0[right_line[i][0] * 230 + right_line[i][1]] + R;
               //cen_j = RST1[right_line[i][0] * 230 + right_line[i][1]] + R;
               cen_i = RST0[right_line[i][0] * Y_MAX + right_line[i][1]] + R*sin(pi - e1);
               cen_j = RST1[right_line[i][0] * Y_MAX + right_line[i][1]] + R*cos(pi - e1);

               if ((cen_i<forward_look) && (cen_j<Y_MAX_OUT)  && (cen_j>0))
                {
                    center[center_dot][0] = cen_i;
                    center[center_dot++][1] = cen_j;
                    sum_hang[cen_i/10][0]+=cen_i;
                    sum_hang[cen_i/10][1]+=cen_j;
                    sum_dot_h[cen_i/10]++;
                }
           }
          // center[i-1][0]=RST0[right_line[i][0]*180+right_line[i][1]];
          //center[i-1][1]=RST1[right_line[i][0]*180+right_line[i][1]]-50;
      }
     for(ave_i=0;ave_i<X_MAX_OUT/10;ave_i++)
      {
          if(sum_dot_h[ave_i]>=1)
           {
               ave_line[ave_dot][0]=sum_hang[ave_i][0]/sum_dot_h[ave_i];
               ave_line[ave_dot++][1]=sum_hang[ave_i][1]/sum_dot_h[ave_i];
           }
      }
     
     if(center_dot) center_change=center_dot-1;
     for (i=change_right_dot+5; i<right_dot-5; i+=3)
      {
          //k=1*solv_line_k(right_line,right_dot*i/dot_num-3,right_dot*i/dot_num+3);
          k = solv_line_k(right_line, i-4 , i + 4, 1, &B,2,1);
          // k4=k;
          e1 = atan(k);
          //e=e1;
          //k_test[i]=k;
          // cen_i = RST0[right_line[i][0] * 230 + right_line[i][1]] + R;
          //cen_j = RST1[right_line[i][0] * 230 + right_line[i][1]] + R;
          if(type==1)
           {
               cen_i = RST0[right_line[i][0] * Y_MAX + right_line[i][1]] - R*cos(pi - e1);
               cen_j = RST1[right_line[i][0] * Y_MAX + right_line[i][1]] - R*sin(pi - e1);
           }
          else if(type==2)
           {
               cen_i = RST0[right_line[i][0] * Y_MAX + right_line[i][1]] + R*cos(pi - e1);
               cen_j = RST1[right_line[i][0] * Y_MAX + right_line[i][1]] + R*sin(pi - e1);
           }
          if ((cen_i<forward_look) && (cen_j<Y_MAX_OUT) && (cen_j>0))
           {
               center[center_dot][0] = cen_i;
               center[center_dot++][1] = cen_j;
               sum_lie[cen_j/10][0]+=cen_i;
               sum_lie[cen_j/10][1]+=cen_j;
               sum_dot_l[cen_j/10]++;
           }
          // center[i-1][0]=RST0[right_line[i][0]*180+right_line[i][1]];
          //center[i-1][1]=RST1[right_line[i][0]*180+right_line[i][1]]-50;
      }
     for(ave_i=0;ave_i<Y_MAX_OUT/10;ave_i++)
      {
          if(sum_dot_l[ave_i]>=1)
           {
               ave_line[ave_dot][0]=sum_lie[ave_i][0]/sum_dot_l[ave_i];
               ave_line[ave_dot++][1]=sum_lie[ave_i][1]/sum_dot_l[ave_i];
           }
      }
 }
void get_roll_left(uint32 R,uint16 forward_look)
 {
     ave_dot=0;
     float k, e1, prop = 1, B;
     int16 i = 0, cen_i, cen_j, dot_def = 0, end_dot;
     uint16 sum_hang[30][2]={0},sum_lie[35][2]={0},sum_dot_h[30]={0},sum_dot_l[30]={0},ave_i=0;
     for (i = 6; i<change_left_dot; i+=3)
      {
          if((i>change_left_dot-5)&&(i<change_left_dot))
           {
               k = solv_line_k(left_line, i - 5, i , 1, &B,1,0);
               e1 = atan(k);
               //e=e1;
               //k_test[i]=k;
               cen_i = RST0[left_line[i][0] * Y_MAX + left_line[i][1]] + R*sin(e1 / -1);
               cen_j = RST1[left_line[i][0] * Y_MAX + left_line[i][1]] + R*cos(e1 / -1);
               if ((cen_i<forward_look) && (cen_j<Y_MAX_OUT)  && (cen_j>0))
                {
                    center[center_dot][0] = cen_i;
                    center[center_dot++][1] = cen_j;
                }
           }
           else
            {
                k = solv_line_k(left_line, i - 5, i + 5, 1, &B,2,0);
                // k4=k;
                e1 = atan(k);
                //e=e1;
                //k_test[i]=k;
                cen_i = RST0[left_line[i][0] * Y_MAX + left_line[i][1]] + R*sin(e1 / -1);
                cen_j = RST1[left_line[i][0] * Y_MAX + left_line[i][1]] + R*cos(e1 / -1);

                if ((cen_i<forward_look) && (cen_j<Y_MAX_OUT)  && (cen_j>0))
                 {
                     center[center_dot][0] = cen_i;
                     center[center_dot++][1] = cen_j;
                     sum_hang[cen_i/10][0]+=cen_i;
                    sum_hang[cen_i/10][1]+=cen_j;
                    sum_dot_h[cen_i/10]++;
                 }
            }
          // center[i-1][0]=RST0[left_line[i][0]*180+left_line[i][1]];
          // center[i-1][1]=RST1[left_line[i][0]*180+left_line[i][1]]+50;
      }
          for(ave_i=0;ave_i<X_MAX_OUT/10;ave_i++)
      {
          if(sum_dot_h[ave_i]>=1)
           {
               ave_line[ave_dot][0]=sum_hang[ave_i][0]/sum_dot_h[ave_i];
               ave_line[ave_dot++][1]=sum_hang[ave_i][1]/sum_dot_h[ave_i];
           }
      }
     if(center_dot) center_change=center_dot-1;
     for (i =change_left_dot+5; i<left_dot-5; i+=3)
      {
          k = solv_line_k(left_line, i-4 , i +4, 1, &B,2,1);
          // k4=k
          e1 = atan(k);
          //e=e1;
          //k_test[i]=k;
          if(type==1)
           {
               cen_i = RST0[left_line[i][0] * Y_MAX + left_line[i][1]] - R*cos(e1 / -1);
               cen_j = RST1[left_line[i][0] * Y_MAX + left_line[i][1]] - R*sin(e1 / -1);
           }
          else if(type==2)
           {
               cen_i = RST0[left_line[i][0] * Y_MAX + left_line[i][1]] +R*cos(e1 / -1);
               cen_j = RST1[left_line[i][0] * Y_MAX + left_line[i][1]] + R*sin(e1 / -1);
           }
          if ((cen_i<forward_look) && (cen_j<Y_MAX_OUT)  && (cen_j>0))
           {
               center[center_dot][0] = cen_i;
               center[center_dot++][1] = cen_j;
               sum_lie[cen_j/10][0]+=cen_i;
               sum_lie[cen_j/10][1]+=cen_j;
               sum_dot_l[cen_j/10]++;
           }
      }
          for(ave_i=0;ave_i<Y_MAX_OUT/10;ave_i++)
      {
          if(sum_dot_l[ave_i]>=1)
           {
               ave_line[ave_dot][0]=sum_lie[ave_i][0]/sum_dot_l[ave_i];
               ave_line[ave_dot++][1]=sum_lie[ave_i][1]/sum_dot_l[ave_i];
           }
      }
 }
uint16  change_get(uint16 line[1000][2],uint16 dot_n)
 {
     int16 i,j;
     int16 sub_value=0;
     if(dot_n>60)
      {
          for(i=10;i<dot_n-10;i+=2)
           {
               sub_value=(int16)(line[i+8][1]-line[i][1])-(int16)(line[i][1]-line[i-8][1]);
               if((sub_value>8)||(sub_value<-8)) return i+8;
           }
           return dot_n;
      }
     else return (dot_n);
 }

uint32 area_sum()
 {
     int i;
     uint32 sum_area_left=0,sum_area_right=0;
     for(i=0;i<left_dot;i++)
      {
          sum_area_left+=Y_MAX/2-left_line[i][1];
      }
     for(i=0;i<right_dot;i++)
      {
          sum_area_right+=right_line[i][1]-Y_MAX/2;
      }
     return (sum_area_left+sum_area_right);
 }
#define Dark_defien_max  50
#define Dark_defien_min  10
uint8 identify_angle()//��ֱ�Ƿ���1
 {
     uint16 check_lie,check_1,check_2,check_1_flag=0,check_2_flag=0,identify=0;
     uint16 i,j;
    if(angle_type!=0)
     {
         if(type==1)
          {
              check_lie=(left_line[change_left_dot-1][1]+Y_MAX)/2;
              for(j=check_lie-5;j<check_lie+5;j++)
               {
                   check_1_flag=0;check_2_flag=0;
                   for(i=5;i<X_MAX-5;i++)
                    {
                        if((!check_1_flag)&&(date[i][j]>threshold_left)&&(date[i+1][j]<threshold_left)&&(date[i+2][j]<threshold_left))
                         {
                             check_1_flag=1;check_1=i;
                         }
                        if((check_1_flag)&&(date[i][j]>threshold_left)&&(date[i-1][j]<threshold_left)&&(date[i-2][j]<threshold_left))
                         {
                             check_2_flag=1;check_2=i;
                             break;
                         }
                    }
                   if((check_2_flag)&&(check_2<check_1+Dark_defien_max)&&(check_2>check_1+Dark_defien_min)) identify++;
               }
              if(identify>5) return 0;//��ʾ����ֱ��
              else return 1;//ֱ��
          }
         if(type==2)
          {
              check_lie=right_line[change_right_dot-1][1]/2;
              for(j=check_lie-5;j<check_lie+5;j++)
               {
                   check_1_flag=0;check_2_flag=0;
                   for(i=5;i<X_MAX-5;i++)
                    {
                        if((!check_1_flag)&&(date[i][j]>threshold_right)&&(date[i+1][j]<threshold_right)&&(date[i+2][j]<threshold_right))
                         {
                             check_1_flag=1;check_1=i;
                         }
                        if((check_1_flag)&&(date[i][j]>threshold_right)&&(date[i-1][j]<threshold_right)&&(date[i-2][j]<threshold_right))
                         {
                             check_2_flag=1;check_2=i;
                             break;
                         }
                    }
                   if((check_2_flag)&&(check_2<check_1+Dark_defien_max)&&(check_2>check_1+Dark_defien_min)) identify++;
               }
              if(identify>5) return 0;
              else return 1;
          }
     }
 }