#include "all.h"
float idealPitch=0.0f,idealRoll=0.0f,idealYaw=0.0f;//����Ԥ�ڽǶ�
float Kpx=0.0f,Kix=0.0f,Kdx=0.0f;//����x���������Ƕȵ�PID����
float Kpy=0.0f,Kiy=0.0f,Kdy=0.0f;
float Kpz=0.0f,Kiz=0.0f,Kdz=0.0f;

float PWM1=0.0f,PWM2=0.0f,PWM3=0.0f,PWM4=0.0f;
float driver1=0.0f,driver2=0.0f,driver3=0.0f,driver4=0.0f;

void PID_init()
 {
        idealPitch = 0;
        idealRoll = 0;
        idealYaw = 0;
        Kpx = 15;
        Kix = 0;
        Kdx = 0;
        Kpy = 9;
        Kiy = 0;
        Kdy = 0.25;
        Kpz = 0;
        Kiz = 0;
        Kdz = 0;
        driver1 = driver2 = driver3 = driver4 =5;    //di���T
 }

void PID_Control()
 {
     static float max_sum=4000,min_sum=-4000;
     static float sum_pitch=0.0f,sum_Roll=0.0f,sum_Yaw=0.0f;
     float Pitch_error,Roll_error,Yaw_error;
     float Pit_out,Rol_out,Yaw_out;
     
     Pitch_error=Pitch-idealPitch;
     Roll_error=Roll-idealRoll;
     Yaw_error=Yaw-idealYaw;
     
     if(sum_pitch>max_sum) sum_pitch=max_sum;
     else if(sum_pitch<min_sum) sum_pitch=min_sum;
     if(sum_Roll>max_sum) sum_Roll=max_sum;
     else if(sum_Roll<min_sum) sum_Roll=min_sum;
     if(sum_Yaw>max_sum) sum_Yaw=max_sum;
     else if(sum_Yaw<min_sum) sum_Yaw=min_sum;
     
     Pit_out=Kpx*Pitch_error+Kix*sum_pitch+Kdx*gyro[1];
     Rol_out=Kpy*Roll_error+Kiy*sum_Roll+Kdy*gyro[0];
     Yaw_out=Kpz*Yaw_error+Kiz*sum_Yaw-Kdz*gyro[2];
     
     //PWM1=driver1+
     PWM2=driver2+Rol_out/500;
     //PWM3
     PWM4=driver4-Rol_out/500;
 }