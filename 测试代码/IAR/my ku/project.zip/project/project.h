#ifndef __PROJECT_H__
#define __PROJECT_H__


void display(uint8 x,uint8 y,int32 num);
void display_DMP(uint8 x,uint8 y,int32 num);
void motor_PWM_init(uint32 Freq,float duty);
void motor_dutyset(float pwm1_duty,float pwm2_duty,float pwm3_duty,float pwm4_duty);
void translate_uart(short acc);

void send_float(uint32 UART_NUM,float val);
//�������ݵ�����������ʾ��line_num:1-6,��ʾ���߱��
//val:Ҫ�������ֵ
void send_line(uint32 UART_NUM,char line_num,float val);
//**************************************************************
//pose_mode:pose_power
//          pose_pitch
//          pose_roll
//          pose_yaw
//**************************************************************
void send_pose(uint32 UART_NUM,char pose_mode,float pose);

void led_init();
void led_set(char led1,char led2,char led3,char led4);
















#endif